<?php
$db = mysqli_connect('localhost','root','','login')
        or die('Error connecting to MySQL server.');
        
        
$select = "UPDATE subscriptionlist set subStatus = 'ACCEPT' where subID='".$_GET['acc_id']."'";
$select1 = "INSERT INTO cussublist(cussubID,cussubStatus) SELECT subID,subStatus FROM subscriptionlist where subID='".$_GET['acc_id']."'";
$select2="DELETE FROM subscriptionlist where subID='".$_GET['acc_id']."'";
$query = mysqli_query($db, $select) or die($select);
$query = mysqli_query($db, $select1) or die($select1);
$query = mysqli_query($db, $select2) or die($select2);
$result = mysqli_query($db,$query);
header ("Location: subscriptionlist.php");
?>