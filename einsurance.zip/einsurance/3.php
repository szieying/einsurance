<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li class="active"><a href="customerMain.php">Home</a></li>
        <li><a href="productCatalog.php">Insurance Plans</a></li>
        <li><a href="recommendation.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<style>

    /* title of table*/
    h1.title{
        margin-top: 100px;
        
        text-align: center;
    }
    
    /*style for table*/
    #favtable{
        font-family:'Open Sans', sans-serif !important;
    border-collapse: collapse;
    
    margin: 0 auto;
    width: 70%;
    transform: translateZ(0);
    -webkit-transform: translateZ(0);
    }
    
    #favtable td, #favtable th{
        border: 1px solid #ddd;
    padding: 8px;
    }
    
    #favtable tr:nth-child(even){
        background-color: #f2f2f2;
    }
    
    #favtable tr:hover {
        background-color: #ddd;
    }
    
    #favtable th{
        padding-top: 12px;
    padding-bottom: 12px;
    text-align: center;
    background-color: #c11d29;
    color: white;
    }
    
    
    
    *{margin:0px; padding:0px; font-family:Helvetica, Arial, sans-serif;}

/* Full-width input fields */
input[type=text], input[type=password] {
    width: 90%;
    padding: 12px 20px;
    margin: 8px 26px;
    display: inline-block;
    border: 1px solid #ccc;
    box-sizing: border-box;
	font-size:16px;
}

/* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 90%;
	font-size:20px;
}
button:hover {
    opacity: 0.8;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 0 auto;
  
    width: 70%;
    transform: translateZ(0);
    -webkit-transform: translateZ(0);
}
.avatar {
    width: 200px;
	height:200px;
    border-radius: 50%;
}

/* The Modal (background) */
.modal {
	display:none;
    
  
    left: 0;
    top: 50px;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.4);
    transform: translateZ(0);
    -webkit-transform: translateZ(0);
}

/* Modal Content Box */
.modal-content {
    background-color: #fefefe;
    margin: 0 auto;
    border: 1px solid #888;
    width: 80%; 
	padding-bottom: 30px;
}


/* Add Zoom Animation */
.animate {
    animation: zoom 0.6s
}

.background{
    font-size: 16px;
    background-color: blue;
}

@keyframes zoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
    </style>
    <div>
        <h1 class="title">SUBSCRIPTION REQUEST </h1>
    </div>
    <table id = "favtable" border="1">
    <?php
        $db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        $select = "SELECT fsproduct.*, product.*,customer.*"
                . " FROM ((fsproduct "
                . "JOIN product ON fsproduct.pID = product.pID)"
                . "JOIN list ON fsproduct.listID = list.listID)"
                . "JOIN customer ON customer.userID = list.userID))"
                 ;
        $query = mysqli_query($db, $select) or die($select);
       ?>
        
        <tr>
            <th colspan="2">Product Information</th>
            <th>Subscribe by</th>
            <th colspan="2">Action</th>
        </tr>
    <?php while($row = mysqli_fetch_assoc($query)){
        if ($row['pType'] == 'M'){
            $image = "medical.jpg";
            
        }
        else if ($row['pType'] == 'S'){
            $image = "sav.png";
            
        }
        else if ($row['pType'] == 'E'){
            $image = "edu.png";
            
        }
        else if ($row['pType'] == 'L'){
            $image = "life insurance.png";
            
        }
 else   
{
     $image = "no.svg";
    }

        
        ?>
        <tr>
            <td><?php echo '<img src="img/' . $image . '" alt="Fjords" width="150" height="100"/>'; ?></td>

            <td><a data-toggle="modal" href="#modal-wrapper"><?php echo $row["pName"];?></a>
                        </td>
            <td><a data-toggle="modal" href="#modal-wrapper"><?php echo $row["userID"];?></a>
                        </td>
            
            
            <td><input type="button" onClick="rejectme(<?php echo $row['subID']; ?>)" name="Reject" value="Reject"></td>
            <td><input type="button" onClick="acceptme(<?php echo $row['subID']; ?>)" name="Accept" value="Accept"></td>
            
        </tr>
        
        <script language="javascript">
       function acceptme(accept)
        {
            if(confirm("Do you want Accept!"))
            {
                window.location.href='3-1.php?acc_id=' +accept+'';
                return true;
            }
        } 
        function rejectme(reject)
        {
            if(confirm("Do you want Reject!"))
            {
                window.location.href='3-2.php?rej_id=' +reject+'';
                return true;
            }
        } 
        </script>
    <?php
    }
     ?>
    
    </table>
    
<div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" action="/action_page.php">
        
    <div class="imgcontainer">
     <img src="img/medical.jpg" alt="medi" class="avatar">
      <h3 style="text-align:center">REQUEST DETAILS</h3>
    </div>

    <div class="imgcontainer">
        <?php
        $db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        $query="select * from customer,list where customer.userID = list.userID";
        $result = mysqli_query($db,$query);
        $row = mysqli_fetch_assoc($result);?>
        <section class="background">
            <h1>CUSTOMER INFORMATION</h1>
            </section>
        <table id = "favtable" border="1">
            <tr><td>Name:</td><td><?php echo $row["cFirstName"]." ".$row["cLastName"] ;?></td></tr>
            <tr><td>Gender:</td><td><?php echo $row["cGender"];?></td></tr>
            <tr><td>NRIC:</td><td><?php echo $row["cNRIC"];?></td></tr>
            <tr><td>DOB:</td><td><?php echo $row["cDOB"];?></td></tr>
            <tr><td>Address:</td><td><?php echo $row["cAddress"];?></td></tr>
            <tr><td>Phone No:</td><td><?php echo $row["cPhoneNo"];?></td></tr>
        </table>
       
    </div>
      
      <script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>
 
 </body>
</html>