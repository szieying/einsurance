<a class="dropdown-toggle" href="#" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span><span style="color:red"> LOGIN</span></a>
    <div class="dropdown-menu" style="padding: 15px; padding-bottom: 10px;">
        <div class="login-box">
            <div class="login-box-body">
                <p class="login-box-msg">eInsurance Member</p>
                <form action="connect/login.db.php" method="post">
                <div class="form-group has-feedback">
                    <input type="text" name="userEmail" placeholder="UserEmail" class="form-control" id="login" maxlength="80" size="30">
                    <span class="glyphicon glyphicon-user form-control-feedback"></span>
                    <span><font color="red"></font></span>
                </div>

                <div class="form-group has-feedback">
                    <input type="password" name="password" value="" placeholder="Password" class="form-control" id="password" size="30">
                    <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                    <span><font color="red"></font></span>
                </div>

                <div class="form-group">
                    <div class="row">
                    <div class="col-xs-7">
                        <a href="http://myadcubes.com/user/auth/forgot_password"><p><font color="GREEN">Forgot Password?</font></p></a>
                    </div>

                    <div class="col-xs-5 pull-right">
                        <input type="submit" name="submit" id="submit" tabindex="4" class="form-control btn btn-success" value="Log In">
                    </div>
                </div>
                      </div>

                <div class="form-group">
                    <div class="row">
                        <div class="col-sm-12">
                           <span>Not a member?</span><a href="register.php"><p><font color="GREEN">Sign up now</font></p></a>
                        </div>
                    </div>
                </div>
                </form>

            </div>
        </div>
    </div>
