<?php include ('templates/header.php'); ?>
<?php include('connect/session.db.php');?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li class="active"><a href="customerMain.php">Home</a></li>
        <li><a href="productCatalog.php">Insurance Plans</a></li>
        <li><a href="recommendationProcess.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<style>
    #favtable{
        font-family:'Open Sans', sans-serif !important;
    border-collapse: collapse;
    position: relative;
    margin: 0 auto;
    width: 70%;
    }
    
    #favtable td, #favtable th{
        border: 1px solid #ddd;
    padding: 8px;
    }
    
    #favtable tr:nth-child(even){
        background-color: #f2f2f2;
    }
    
    #favtable tr:hover {
        background-color: #ddd;
    }
    
    #favtable th{
        padding-top: 12px;
    padding-bottom: 12px;
    text-align: center;
    background-color: #c11d29;
    color: white;
    }
    
    h1.title{
        margin-top: 100px;
        text-align: center;
    }
    
        /* Set a style for all buttons */
button {
    background-color: #4CAF50;
    color: white;
    padding: 14px 20px;
    margin: 8px 26px;
    border: none;
    cursor: pointer;
    width: 90%;
	font-size:20px;
}
button:hover {
    opacity: 0.8;
}

/* Center the image and position the close button */
.imgcontainer {
    text-align: center;
    margin: 0 auto;
  
    width: 70%;
    transform: translateZ(0);
    -webkit-transform: translateZ(0);
}
.avatar {
    width: 200px;
	height:200px;
    border-radius: 50%;
}

/* The Modal (background) */
.modal {
	display:none;
    
  
    left: 0;
    top: 50px;
    width: 100%;
    height: 100%;
    overflow: auto;
    background-color: rgba(0,0,0,0.4);
    transform: translateZ(0);
    -webkit-transform: translateZ(0);
}

/* Modal Content Box */
.modal-content {
    background-color: #fefefe;
    margin: 0 auto;
    border: 1px solid #888;
    width: 80%; 
	padding-bottom: 30px;
}


/* Add Zoom Animation */
.animate {
    animation: zoom 0.6s
}

.background{
    font-size: 16px;
    background-color: blue;
}

@keyframes zoom {
    from {transform: scale(0)} 
    to {transform: scale(1)}
}
    
    </style>
    <div>
        <h1 class="title">SUBSCRIPTION LIST</h1>

</div>
<table id = "favtable" border="1">
    <?php
    $userID=$_SESSION['loginUser_ID'];
        $db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        $select = "SELECT fsproduct.*, product.*,list.*"
                . " FROM ((fsproduct "
                . "JOIN product ON fsproduct.pID = product.pID)"
                . "JOIN list ON fsproduct.listID = list.listID)"
                . "WHERE listType = 'S' AND userID='$userID'"                ;
        $query = mysqli_query($db, $select) or die($select);
       ?>
        <tr>
            <th colspan="2">Product</th>
            <th>Price</th>
            <th colspan="2">Status</th>
            
        </tr>
    <?php while($row = mysqli_fetch_assoc($query))
    {
        if ($row['pType'] == 'M') {
   $image = "medical.jpg";
}
else if ($row['pType'] == 'S'){
    $image = "sav.png";
}
else if ($row['pType'] == 'E'){
    $image = "edu.png";
}
else if ($row['pType'] == 'L'){
    $image = "life insurance.png";
}
 else   
{
     $image = "no.svg";
    }

        
        ?>
        <tr>
            <td><?php echo '<img src="img/' . $image . '" alt="Fjords" width="150" height="100"/>'; ?></td>
            <td><br><a data-toggle="modal" href="#modal-wrapper"><?php echo $row["pName"];?></a>
                        </br>
           </td>
           <td><?php echo $row["pPrice"];?></td>
            <td><?php echo $row["subscribeStatus"];?></td>
            
        </tr>
        
        
    <?php
    }
     ?>
    
    </table>
    
    <div id="modal-wrapper" class="modal">
  
  <form class="modal-content animate" action="/action_page.php">
        
    <div class="imgcontainer">
     <img src="img/medical.jpg" alt="medi" class="avatar">
      <h3 style="text-align:center">PRODUCT INFORMATION</h3>
    </div>

    <div class="imgcontainer">
         <?php
        $db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        $select = "SELECT fsproduct.*, product.*,list.*"
                . " FROM ((fsproduct "
                . "JOIN product ON fsproduct.pID = product.pID)"
                . "JOIN list ON fsproduct.listID = list.listID)"
                ;
        $query = mysqli_query($db, $select) or die($select);
       $row = mysqli_fetch_assoc($query)
        ?>
            <table id = "favtable" border="1">
            <tr><td> ID:</td><td><?php echo $row["pID"];?></td></tr>
            <tr><td> Type:</td><td><?php echo $row["pType"];?></td></tr>
            <tr><td> Name:</td><td><?php echo $row["pName"];?></td></tr>
            <tr><td> Coverage Lowest Limit:</td><td><?php echo $row["pCoverage_LLimit"];?></td></tr>
            <tr><td> Coverage Upper Limit:</td><td><?php echo $row["pCoverage_ULimit"];?></td></tr>
            <tr><td> Age Range Lowest Limit:</td><td><?php echo $row["pAgeRange_LLimit"];?></td></tr>
            <tr><td> Age Range Upper Limit:</td><td><?php echo $row["pAgeRange_ULimit"];?></td></tr>
            <tr><td> Coverage Term</td><td><?php echo $row["pCoverageTerm"];?></td></tr>
            <tr><td> Description</td><td><?php echo $row["pDescription"];?></td></tr>
            <tr><td> Company</td><td><?php echo $row["pCompany"];?></td></tr>
            <tr><td> Price</td><td><?php echo $row["pPrice"];?></td></tr>
        </table>
       
    </div>
      <script>
// If user clicks anywhere outside of the modal, Modal will close

var modal = document.getElementById('modal-wrapper');
window.onclick = function(event) {
    if (event.target == modal) {
        modal.style.display = "none";
    }
}
</script>

 </body>
</html>
