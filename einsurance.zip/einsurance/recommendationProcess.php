<?php include('connect/session.db.php');?>
<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href="customerMain.php">Home</a></li>
        <li><a href="productCatalog.php">Insurance Plans</a></li>
        <li class="active"><a href="recommendationProcess.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<div id="recommendationProcess" class="container">
<!-- multistep form -->
<form id="msform" action="connect/productRecommend.php" method="post">
	<!-- progressbar -->

        <ul id="progressbar">
		<li class="active">Preferences</li>
		<li>Confirm Your Profile Details</li>
                
	</ul>
	<!-- fieldsets -->
	<fieldset>
		<h2 class="fs-title">Preferences</h2>
                <h6>* Please select the applicant and the type of products you prefer.</h6>
                <label for="Name">Applicant's Age</label> 
                <input type="number" name="age" placeholder="AGE" />
                
                <label for="Name">Product Type</label> 
                <select name="pType">
                    <option value="M">Medical</option>
                    <option value="L">Life</option>
                    <option value="S">Savings</option>
                    <option value="E">Education</option>
                </select>
                
                <input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	<fieldset>
                <h2 class="fs-title">Your Profile</h2>
		<h6>* Please fill in your information.</h6>
                <label for="Name">Your Age</label> 
                <input type="number" name="CAge" placeholder="AGE" />
                <label for="Name">MARITAL STATUS</label> 
                <select name="MaritalStatus">
                    <option value="N">NO</option>
                    <option value="Y">YES</option>
                </select>
                <label for="Name">NUMBER OF DEPENDANTS</label> 
                <input type="number" name="dependants" placeholder="Number of Dependants" />
		<h3 class="fs-title">Employment</h3>
                <label for="Name">SALARY (RM)</label> 
                <input type="number" name="Salary" placeholder="SALARY" />

		<h3 class="fs-title">Expenses Behavior</h3>
                <h6>* The expenses listed is for one month.</h6>
                <label for="Name">COST FOR DEPENDANTS (RM)</label> 
		<input type="number" name="DCost" placeholder="Total of parents living cost, child education fee, ..." />
                <label for="Name">MORTGAGE (RM)</label> 
		<input type="number" name="Mortgage" placeholder="Total of loan or debts" />
                <label for="Name">LIVING COST (RM)</label> 
		<input type="number" name="LivingCost" placeholder="Living Cost" />
                <label for="Name">Shopping Frequency</label> 
                <select name="shopFrequency">
                    <option value="1">once per month</option>
                    <option value="2">twice per month</option>
                    <option value="3">thrice per month</option>
                    <option value="4">once a week</option>
                    <option value="5">twice a week</option>
                    <option value="6">more than twice a week</option>
                </select>
                <label for="Name">Expenses Per Shopping</label> 
                <select name="shopSpend">
                    <option value="1">RM 0 - 499</option>
                    <option value="2">RM 500 - 999</option>
                    <option value="3">RM 1000 - 1499</option>
                    <option value="4">RM 1500 - 1999</option>
                    <option value="5">above RM 2000</option>
                </select>
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="submit" name="submitRecommend" id="submitRecommend" class="submit action-button" value="Submit" />
	</fieldset>
</form>
</div>
    
 </div><br>   

 <div class="container" style="margin-bottom:1100px"></div><hr>
<?php include "templates/footer.php"; ?>

<!-- jQuery -->
<script src="http://thecodeplayer.com/uploads/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<!-- jQuery easing plugin -->
<script src="http://thecodeplayer.com/uploads/js/jquery.easing.min.js" type="text/javascript"></script>


<style>
  
    
    
    /*custom font*/
@import url(http://fonts.googleapis.com/css?family=Montserrat);

/*basic reset*/
* {margin: 0; padding: 0;}

body {
	font-family: montserrat, arial, verdana;
}
/*form styles*/
#msform {
	width: 80% ;
	margin: 0 auto;
        margin-top: 100px;
	text-align: left;
	position: relative;
}

label{
    text-align: center;
}

#msform fieldset {
	background: white;
	border: 0 none;
	border-radius: 3px;
	box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
	padding: 20px 30px;
	
	box-sizing: border-box;
	width: 80%;
	margin: 0 10%;
	
	/*stacking fieldsets above each other*/
	position: absolute;
}
/*Hide all except first fieldset*/
#msform fieldset:not(:first-of-type) {
	display: none;
}
/*inputs*/
#msform input, #msform textarea, #msform select {
	padding: 15px;
	border: 1px solid #ccc;
	border-radius: 3px;
	margin-bottom: 10px;
	width: 100%;
	box-sizing: border-box;
	font-family: montserrat;
	color: #2C3E50;
	font-size: 13px;
}
/*buttons*/
#msform .action-button {
	width: 100px;
	background: #c11d29;
	font-weight: bold;
	color: white;
	border: 0 none;
	border-radius: 1px;
	cursor: pointer;
	padding: 10px 5px;
	margin: 10px 5px;
}
#msform .action-button:hover, #msform .action-button:focus {
	box-shadow: 0 0 0 2px white, 0 0 0 3px #27AE60;
}
/*headings*/
.fs-title {
	font-size: 15px;
	text-transform: uppercase;
	color: #2C3E50;
	margin-bottom: 10px;
        text-align: center;
}
.fs-subtitle {
	font-weight: normal;
	font-size: 13px;
	color: #666;
	margin-bottom: 20px;
        text-align: center;
}
/*progressbar*/
#progressbar {
	margin-bottom: 30px;
	overflow: hidden;
	/*CSS counters to number the steps*/
	counter-reset: step;
}
#progressbar li {
	list-style-type: none;
	color: black;
	text-transform: uppercase;
	font-size: 12px;
	width: 50%;
	float: left;
	position: relative;
        text-align: center;
}
#progressbar li:before {
	content: counter(step);
	counter-increment: step;
	width: 20px;
	line-height: 20px;
	display: block;
	font-size: 12px;
	color: white;
	background: black;
	border-radius: 3px;
	margin: 0 auto 5px auto;
}
/*progressbar connectors*/
#progressbar li:after {
	content: '';
	width: 100%;
	height: 2px;
	background: black;
	position: absolute;
	left: -50%;
	top: 9px;
	z-index: -1; /*put it behind the numbers*/
}
#progressbar li:first-child:after {
	/*connector not needed before the first step*/
	content: none; 
}
/*marking active/completed steps green*/
/*The number of the step and the connector before it = green*/
#progressbar li.active:before,  #progressbar li.active:after{
	background: #c11d29;
	color: white;
}
</style>
    
    
<script>
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'transform': 'scale('+scale+')'});
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});
</script>