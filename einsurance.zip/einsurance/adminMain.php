<?php include('connect/session.db.php');?>
<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="adminMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="">Home</a></li>
        <li><a href="#RecommendationProcess">What is Insurance?</a></li>
        <li><a href="#Services">Services Provided</a></li>
        <li><a href="#Partners">Our Partners</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right" style="padding-right:20px;">
        <li class="dropdown">
            <a class="dropdown-toggle" href="#" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span><span style="color:#c11d29"> Hello, <i><?php echo $login_session; ?></i></span></a>
            <ul id="dropDownMenu" class="dropdown-menu" style="padding: 15px; padding-bottom: 10px;">
            <li><a href="connect/logout.db.php">Sign Out</a></li>
            </ul>
      </ul>
    </div>
  </div>
</nav>

<?php include "templates/footer.php"; ?>