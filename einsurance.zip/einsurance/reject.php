<?php
$db = mysqli_connect('localhost','root','','login')
        or die('Error connecting to MySQL server.');
        
        $result = mysqli_query($db,$query);
$select = "UPDATE subscriptionlist set subStatus = 'REJECT' where subID='".$_GET['rej_id']."'";
$select1 = "INSERT INTO cussublist(cussubID,cussubStatus) SELECT subID,subStatus FROM subscriptionlist where subID='".$_GET['rej_id']."'";
$select2="DELETE FROM subscriptionlist where subID='".$_GET['rej_id']."'";
$query = mysqli_query($db, $select) or die($select);
$query = mysqli_query($db, $select1) or die($select1);
$query = mysqli_query($db, $select2) or die($select2);
header ("Location: subscriptionlist.php");
?>