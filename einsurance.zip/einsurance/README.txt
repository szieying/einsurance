===================================================================
-- MUST PULL down latest version of code first before PUSH --
===================================================================

--------------------------------
To import database "einsurance"
--------------------------------
1) First need to drop database if had created previously with same name.

2) Then click "Import" 
    (need to open localhost/phpmyadmin ONLY 
        **no extra words behind the phpmyadmin)

To drop database
1) click the database (left panel)
2) then select "Operations" , 
    scroll down beside left panel corner there 
        have "DROP the database (DROP)" in red words
3) Just click that then drop the database