<?php 
$connection = mysqli_connect("localhost", "root", ""); // Establishing Connection with Server
$db_select = mysqli_select_db( $connection, "einsurance");  // Selecting Database from Server
if(isset($_POST['submit'])){ // Fetching variables of the form which travels in URL
$name = $_POST['pID'];
$email = $_POST['pName'];
$contact = $_POST['pType'];
$address = $_POST['pCompany'];
$address = $_POST['pPrice'];
$address = $_POST['pCoverage'];
$address = $_POST['pCoverageTerm'];
$address = $_POST['pAgeRange'];
$address = $_POST['pScore'];
if($pID !=''||$pName !=''){
//Insert Query of SQL
$query = mysqli_query("insert into insuranceproduct(pID,pName,pType,pCompany,pPrice,pCoverage,pCoverageTerm,pAgeRange,pScore) values ('$pID', '$pName', '$pType', '$pCompany' , '$pPrice' , '$pCoverage' , '$pCoverageTerm', '$pAgeRange', '$pScore' )");
echo "<br/><br/><span>Data Inserted successfully...!!</span>";
}
else{
echo "<p>Insertion Failed <br/> Some Fields are Blank....!!</p>";
}
}
mysqli_close($connection); // Closing Connection with Server ?>
 
 <head>
	  <title>Product Details</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/headerstyle.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

<body>
	<nav class="navbar navbar-default navbar-custom navbar-fixed-top">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="http://localhost/eInsurance"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
	    </div>

    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#"><strong>Home</strong></a></li>
        <li><a href="#RecommendationProcess"><strong>Product</strong></a></li>
        <li><a href="#Services"><strong>How It Works?</strong></a></li>
        <li><a href="#Partners"><strong>Our Partners</strong></a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" href="#" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span> <strong>ADMIN</strong></a>
          <div class="dropdown-menu" style="padding: 15px; padding-bottom: 10px;">
            <div class="login-box">
              <div class="login-box-body">
                      <p class="login-box-msg">eInsurance Members</p>
                    <form action="connect/login.php" method="post">
                      <div class="form-group has-feedback">
                        <input type="text" name="userEmail" placeholder="UserEmail" class="form-control" id="login" maxlength="80" size="30">
                        <span class="glyphicon glyphicon-user form-control-feedback"></span>
                        <span><font color="red"></font></span>
                      </div>

                      <div class="form-group has-feedback">
                        <input type="password" name="password" value="" placeholder="Password" class="form-control" id="password" size="30">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                        <span><font color="red"></font></span>
                      </div>

                      <div class="form-group">
                        <div class="row">
                            <div class="col-xs-7">
                                <a href="http://myadcubes.com/user/auth/forgot_password"><p><font color="GREEN">Forgot Password?</font></p></a>
                            </div>

                            <div class="col-xs-5 pull-right">
                                <input type="submit" name="submit" id="submit" tabindex="4" class="form-control btn btn-success" value="Log In">
                            </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12">
                             <span>Not a member?</span><a href="register.php"><p><font color="GREEN">Sign up now</font></p></a>
                           </div>
                        </div>
                      </div>
                  </form>

                  </div>
                </div>
          </div>
      </ul>
    </div>
  </div>
</nav>

</body>
<style>
p.ex1 {
    margin-top: 3cm;
}
</style>
      
  <p class="ex1"><h2 class="text-center">PRODUCT DETAILS</h2></p><br>


<div class="container">
<div class="row">
  <form class="form-horizontal" action="/action_page.php">
    <div class="form-group">
      <label class="control-label col-sm-2" for="pID">Product ID:</label>
      <div class="col-sm-10">
        <input type="pID" class="form-control" id="pID" placeholder="Enter Product ID" name="pID">
      </div>
    </div>
    <div class="form-group">
      <label class="control-label col-sm-2" for="pName">Product Name:</label>
      <div class="col-sm-10">          
        <input type="pName" class="form-control" id="pName" placeholder="Enter Product Name" name="pName">
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pType">Product Type:</label>
      <div class="col-sm-10">  
		<select class="form-control" id="pType" placeholder="Enter Product Type" name="pType">
		<option>Enter Product Type</option>
		<option>M:Medical</option>
		<option>E:Education</option>
		<option>S:Savings</option>
		<option>L:Life</option>
		</select>
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pCompany">Company Name:</label>
      <div class="col-sm-10">          
        <select class="form-control" id="pCompany" placeholder="Enter Company Name" name="pCompany">
		<option>Enter Company Name</option>
                <option>AIA</option>
		<option>Allianz</option>
		<option>Asia Pasifik</option>
		<option>AXA</option>
                <option>Etiqa</option>
		<option>Great Eastern</option>
                <option>Maybank</option>
                <option>Prudential</option>
		<option>Tokyo Marine</option>
                <option>Zurich</option>
		</select>
      </div>
    </div>
	    <div class="form-group">
      <label class="control-label col-sm-2" for="pPrice">Product Price: RM </label>
      <div class="col-sm-10">          
        <input type="pPrice" class="form-control" id="pPrice" placeholder="Enter Product Price" name="pPrice">
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pCoverage_LLimit">Product Coverage Lower Limit:</label>
      <div class="col-sm-10">          
        <input type="pCoverage_LLimit" class="form-control" id="pCoverage_LLimit" placeholder="Enter Product Coverage Lower Limit" name="pCoverage_LLimit">
      </div>
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="pCoverage_ULimit">Product Coverage Upper Limit:</label>
      <div class="col-sm-10">          
        <input type="pCoverage_ULimit" class="form-control" id="pCoverage_ULimit" placeholder="Enter Product Coverage Upper Limit" name="pCoverage_ULimit">
      </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pCoverageTerm">Product Coverage Term:</label>
      <div class="col-sm-10">          
        <select type="pCoverageTerm" class="form-control" id="pCoverageTerm" placeholder="Enter Product Coverage Term" name="pCoverageTerm">
		<option>Enter Product Coverage Term</option>
                <option>A99</option>
                <option>Y20</option>
      </select>
	  </div>
    </div>
	<div class="form-group">
      <label class="control-label col-sm-2" for="pAgeRange_LLimit">Product Age Lower Limit:</label>
      <div class="col-sm-10">          
        <select type="pAgeRange_LLimit" class="form-control" id="pAgeRange_LLimit" placeholder="Enter Product Age Lower Limit" name="pAgeRange_LLimit">
		<option>Enter Product Age Lower Limit</option>
                <option></option>
                <option></option>
                <option></option>
                <option></option>
                <option></option>
		</select>
      </div>
      
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="pAgeRange_ULimit">Product Age Upper Limit:</label>
      <div class="col-sm-10">          
        <select type="pAgeRange_ULimit" class="form-control" id="pAgeRange_ULimit" placeholder="Enter Product Age Upper Limit" name="pAgeRange_ULimit">
		<option>Enter Product Age Upper Limit</option>
                <option></option>
                <option></option>
                <option></option>
                <option></option>
                <option></option>
		</select>
      </div>
      
    </div>
      <div class="form-group">
      <label class="control-label col-sm-2" for="pDescription">Product Description:</label>
      <div class="col-sm-10">          
        <input type="pDescription" class="form-control" id="pDescription" placeholder="Enter Product Description" name="pDescription">
      </div>
    </div>
	    <div class="form-group">
      <label class="control-label col-sm-2" for="pScore">Product Score:</label>
      <div class="col-sm-10">          
        <select type="pScore" class="form-control" id="pScore" placeholder="Enter Product Score" name="pScore">
		<option>Enter Product Score</option>
                <option>1.0-1.9</option>
                <option>2.0-2.9</option>
                <option>3.0-3.9</option>
		</select>
      </div>
    </div>
    <div class="form-group">        
      <div class="col-sm-offset-11 col-sm-70">
        <button type="submit" class="btn btn-danger">SUBMIT</button>
      </div>
    </div>
  </form>
  </div>
</div><br><br><br>




<?php include "templates/footer.php"; ?>
