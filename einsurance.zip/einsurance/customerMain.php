<?php include('connect/session.db.php');?>
<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li class="active"><a href="customerMain.php">Home</a></li>
        <li><a href="productCatalog.php">Insurance Plans</a></li>
        <li><a href="recommendationProcess.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<div id="Services" class="container text-center" style="margin-top:70px">
   
  <?php include('serviceProvided.html'); ?>
    <hr>
</div>
<div id="Partners" class="container text-center">
   <?php include('partner.html'); ?> 
</div><br>

<?php include "templates/footer.php"; ?>
