<?php
    include 'connect/productRecommend.php';

    $c = new customer($_SESSION['salary'],$_SESSION['maritalStatus'],$_SESSION['eCategory'],$_SESSION['ageCategory']);
    
    class customer{
        public $salary;
        public $maritalStatus;
        public $expensesCategory;
        public $ageCategory;
        
        public function __construct($s,$m,$e,$a) {
            $this->salary=$s;
            $this->maritalStatus=$m;
            $this->expensesCategory=$e;
            $this->ageCategory=$a;
        }
        
        public function checkCondition($condition,$conditionType){
            switch($conditionType){
                case 'salary':
                    $symbol=substr($condition, 0, 2);
                    $number=substr($condition, 2);
                    switch ($symbol){
                        case ('<='):
                            if ($this->salary <= $number) {
                                return true;
                            } else {
                                return false;
                            }
                        case ('> '):
                            if ($this->salary > $number) {
                                return true;
                            } else {
                                return false;
                            }
                    }
                case 'maritalStatus':
                    if ($this->maritalStatus == $condition) {
                        return true;
                    } else {
                        return false;
                    }
                case 'expensesCategory':
                    if ($this->expensesCategory == $condition) {
                        return true;
                    } else {
                        return false;
                    }
                case 'age':
                    if ($this->ageCategory == $condition) {
                        return true;
                    } else {
                        return false;
                    }
            }
        }
    }
    //include 'connect/productRecommend.php';
    
    class Tree{
        public $root=NULL;
        public function __construct(TreeNode $node) {
            $this->root=$node;
        }
        public function traverse(TreeNode $node, $level=0){
            if($node){
                echo str_repeat("- ", $level);
                if($level!=0){
                    echo " ( ". $node->condition .") : ";
                }      
                echo $node->data . "<br />";
                
                foreach ($node->children as $childNode){
                    $this->traverse($childNode,$level+1);
                }
            }
        }
        
        public function search(customer $c, TreeNode $node){
            if(!empty($node)){
              foreach ($node->children as $childNode){
                if($c->checkCondition($childNode->condition, $childNode->conditionType)){
                    if($childNode->type=="cusType"){
                        //echo $c->salary. " ,  ". $c->maritalStatus. " ,  ". $c->expensesCategory. " ,  ". $c->ageCategory. "<br />";
                        //echo $childNode->type. ": ". $childNode->data. "<br />";
                        //$childNode->data;
                        return $childNode->data;
                    }else{
                       // echo $childNode->type. ": ". $childNode->data. ": ". $childNode->condition."<br />";
                        $found = $this->search($c, $childNode);
                        if ($found){ return $found;}
                    }
                }else{
                    continue;
                }                  
              }
            }else{
                echo "Not found!";
            }
        }
        
    }
    
    class TreeNode{
        public $type = NULL;
        public $data = NULL;
        public $condition = NULL;
        public $conditionType=NULL;
        public $children = [];
        
        public function __construct($type,$data,$condition,$conditionType) {
            $this->type=$type;
            $this->data=$data;
            $this->condition=$condition;
            $this->conditionType=$conditionType;
        }
        
        public function addChildren(TreeNode $node) {
            $this->children[]=$node;
           // $child->parent = $this;
        }
    }
    
    
    //ROOT
    $salary1 = new TreeNode("salary","Salary","","");
    $tree = new Tree($salary1);
    //Level 1
    $cus = new TreeNode("cusType","low-end","<=3950","salary");
    $maritalStatus1 = new TreeNode("marital","marital Status","> 3950","salary");
    
    $salary1->addChildren($cus);
    $salary1->addChildren($maritalStatus1);
    //Level 2
    $salary2 = new TreeNode("salary","Salary","Y","maritalStatus");
    $age = new TreeNode("age","Age","N","maritalStatus");
    
    $maritalStatus1->addChildren($salary2);
    $maritalStatus1->addChildren($age);
    //Level 3 - Left
    $expenses1 = new TreeNode("expensesCategory","Expenses Category","<=9500","salary");
    $cus1 = new TreeNode("cusType","high-end","> 9500","salary");
    
    $salary2->addChildren($expenses1);
    $salary2->addChildren($cus1);
    //Level 3 - Right
    $cus2 = new TreeNode("cusType","low-end","1","age");
    $cus3 = new TreeNode("cusType","middle-end","2","age");
    $expenses2 = new TreeNode("expensesCategory","Expenses Category","3","age");
    $cus4 = new TreeNode("cusType","low-end","4","age");
    $salary3 = new TreeNode("salary","Salary","5","age");
    
    $age->addChildren($cus2);
    $age->addChildren($cus3);
    $age->addChildren($expenses2);
    $age->addChildren($cus4);
    $age->addChildren($salary3);
    
    //level 4 - Left
    $cus5 = new TreeNode("cusType","low-end","1","expensesCategory");
    $cus6 = new TreeNode("cusType","middle-end","2","expensesCategory");
    $cus7 = new TreeNode("cusType","low-end","3","expensesCategory");
    $cus8 = new TreeNode("cusType","middle-end","4","expensesCategory");
    $cus9 = new TreeNode("cusType","middle-end","5","expensesCategory");
    
    $expenses1->addChildren($cus5);
    $expenses1->addChildren($cus6);
    $expenses1->addChildren($cus7);
    $expenses1->addChildren($cus8);
    $expenses1->addChildren($cus9);
    
    //level 4 - Right (A)
    $cus10 = new TreeNode("cusType","middle-end","1","expensesCategory");
    $cus11 = new TreeNode("cusType","low-end","2","expensesCategory");
    $cus12 = new TreeNode("cusType","middle-end","3","expensesCategory");
    $cus13 = new TreeNode("cusType","middle-end","4","expensesCategory");
    $cus14 = new TreeNode("cusType","middle-end","5","expensesCategory");
    
    $expenses2->addChildren($cus10);
    $expenses2->addChildren($cus11);
    $expenses2->addChildren($cus12);
    $expenses2->addChildren($cus13);
    $expenses2->addChildren($cus14);
    
    //Level 4 - Right (B)
    $cus15 = new TreeNode("cusType","low-end","<=5100","salary");
    $cus16 = new TreeNode("cusType","middle-end","> 5100","salary");
    
    $salary3->addChildren($cus15);
    $salary3->addChildren($cus16);
    
    //$tree->traverse($tree->root);
    //$c = new customer("9600","N","1","3");
    session_start();
    $_SESSION['cType']=$tree->search($c, $tree->root);
    session_write_close();
    header ("location: recommendProduct.php");
   // echo $node ? " found:  " . $node->data : " not found   ";
?>
    <!--/*
    $cfo = new TreeNode("CFO");
    $cmo = new TreeNode("CMO");
    $coo = new TreeNode("COO");
    
    $ceo->addChildren($cto);
    $ceo->addChildren($cfo);
    $ceo->addChildren($cmo);
    $ceo->addChildren($coo);
    
    $sa = new TreeNode("SA");
    $se = new TreeNode("SE");
    $ui = new TreeNode("UI");
    $qa = new TreeNode("QA");
    
    $cto->addChildren($sa);
    $sa->addChildren($se);
    $cto->addChildren($qa);
    $cfo->addChildren($ui);
    
    $tree->traverse($tree->root);*/-->