<?php include "templates/header.php"; ?>
<?php include('connect/session.db.php');?>
<a class="navbar-brand" href="index.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href="index.php">Home</a></li>
          <li class="active"><a href="">My Profile</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right" style="padding-right:20px;">
        <?php include ('templates/navBarRight.html'); ?> 
      </ul>
    </div>
  </div>
</nav>

<div id="profileForm" class="container">
<!-- multistep form -->
<form id="msform" action="connect/editProfile.db.php" method="post">
	<!-- progressbar -->

        <ul id="progressbar">
		<li class="active">Personal Details</li>
		<li>Employment</li>
		<li>Expenses Behavior</li>
                
	</ul>
	<!-- fieldsets -->
	<fieldset>
		<h2 class="fs-title">Personal Details</h2>
                <h6>* Please fill in your information.</h6>
                <label for="Name">NICKNAME</label> 
                <input type="text" name="Nickname" placeholder="Nickname" maxlength="30"/>
		
                <label for="Name">NAME</label> 
                <input type="text" name="Fname" placeholder="First Name" maxlength="30"/>
                <input type="text" name="Lname" placeholder="Last Name" maxlength="50"/>
		
                <label for="Name">NRIC</label> 
                <input type="text" name="IC" placeholder="900101-07-1111" maxlength="15"/>
                
                <label for="Name">GENDER</label> 
                <select name="Gender">
                    <option value="M">Male</option>
                    <option value="F">Female</option>
                </select>

		<label for="Name">DATE OF BIRTH</label> 
                <input type="date" name="DOB"><br>
                
                <label for="Name">PHONE NUMBER</label> 
		<input type="number" name="Phone" placeholder="PHONE NUMBER" maxlength="12"/>
                
                <label for="Name">ADDRESS</label> 
                <textarea name="Address" placeholder="Address" maxlength="150"></textarea>               
                
                <input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	<fieldset>
		<h2 class="fs-title">Employment</h2>
		<h6>* Please fill in your information.</h6>
                <input type="number" name="Salary" placeholder="SALARY" />
		<input type="text" name="Career" placeholder="OCCUPATION" maxlength="30"/>
                <label for="Name">EMPLOYMENT STATUS</label> 
                <select name="EmploymentStatus">
                    <option value="1">NO JOB</option>
                    <option value="2">Employed</option>
                    <option value="3">Self-Employed</option>
                    <option value="4">Part-Time Worker</option>
                    <option value="5">Housewife</option>
                </select>
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="button" name="next" class="next action-button" value="Next" />
	</fieldset>
	<fieldset>
		<h2 class="fs-title">Expenses Behavior</h2>
                <h6>* The expenses listed is for one month.</h4>
		<h6>* Please fill in your information.</h6>
                <label for="Name">MARITAL STATUS</label> 
                <select name="MaritalStatus">
                    <option value="N">NO</option>
                    <option value="Y">YES</option>
                </select>
                <label for="Name">NUMBER OF DEPENDANTS</label> 
                <input type="number" name="dependants" placeholder="Number of Dependants" />
                <label for="Name">COST FOR DEPENDANTS (RM)</label> 
		<input type="number" name="DCost" placeholder="Total of parents living cost, child education fee, ..." />
                <label for="Name">MORTGAGE (RM)</label> 
		<input type="number" name="Mortgage" placeholder="Total of loan or debts" />
                <label for="Name">LIVING COST (RM)</label> 
		<input type="number" name="LivingCost" placeholder="Living Cost" />
                <label for="Name">Shopping Frequency</label> 
                <select name="shopFrequency">
                    <option value="1">once per month</option>
                    <option value="2">twice per month</option>
                    <option value="3">thrice per month</option>
                    <option value="4">once a week</option>
                    <option value="5">twice a week</option>
                    <option value="6">more than twice a week</option>
                </select>
                <label for="Name">Expenses Per Shopping</label> 
                <select name="shopSpend">
                    <option value="1">RM 0 - 499</option>
                    <option value="2">RM 500 - 999</option>
                    <option value="3">RM 1000 - 1499</option>
                    <option value="4">RM 1500 - 1999</option>
                    <option value="5">above RM 2000</option>
                </select>
		<input type="button" name="previous" class="previous action-button" value="Previous" />
		<input type="submit" name="submitProfile" id="submitProfile" class="submit action-button" value="Submit" />
	</fieldset>
</form>
</div>
<div class="container" style="margin-bottom:900px"></div><hr>
<?php include "templates/footer.php"; ?>


<!-- jQuery -->
<script src="http://thecodeplayer.com/uploads/js/jquery-1.9.1.min.js" type="text/javascript"></script>
<!-- jQuery easing plugin -->
<script src="http://thecodeplayer.com/uploads/js/jquery.easing.min.js" type="text/javascript"></script>


<style>
  
    
    
    /*custom font*/
@import url(http://fonts.googleapis.com/css?family=Montserrat);

/*basic reset*/
* {margin: 0; padding: 0;}

body {
	font-family: montserrat, arial, verdana;
}
/*form styles*/
#msform {
	width: 80% ;
	margin: 0 auto;
        margin-top: 100px;
	text-align: left;
	position: relative;
}

label{
    text-align: center;
}

#msform fieldset {
	background: white;
	border: 0 none;
	border-radius: 3px;
	box-shadow: 0 0 15px 1px rgba(0, 0, 0, 0.4);
	padding: 20px 30px;
	
	box-sizing: border-box;
	width: 80%;
	margin: 0 10%;
	
	/*stacking fieldsets above each other*/
	position: absolute;
}
/*Hide all except first fieldset*/
#msform fieldset:not(:first-of-type) {
	display: none;
}
/*inputs*/
#msform input, #msform textarea, #msform select {
	padding: 15px;
	border: 1px solid #ccc;
	border-radius: 3px;
	margin-bottom: 10px;
	width: 100%;
	box-sizing: border-box;
	font-family: montserrat;
	color: #2C3E50;
	font-size: 13px;
}
/*buttons*/
#msform .action-button {
	width: 100px;
	background: #c11d29;
	font-weight: bold;
	color: white;
	border: 0 none;
	border-radius: 1px;
	cursor: pointer;
	padding: 10px 5px;
	margin: 10px 5px;
}
#msform .action-button:hover, #msform .action-button:focus {
	box-shadow: 0 0 0 2px white, 0 0 0 3px #27AE60;
}
/*headings*/
.fs-title {
	font-size: 15px;
	text-transform: uppercase;
	color: #2C3E50;
	margin-bottom: 10px;
        text-align: center;
}
.fs-subtitle {
	font-weight: normal;
	font-size: 13px;
	color: #666;
	margin-bottom: 20px;
        text-align: center;
}
/*progressbar*/
#progressbar {
	margin-bottom: 30px;
	overflow: hidden;
	/*CSS counters to number the steps*/
	counter-reset: step;
}
#progressbar li {
	list-style-type: none;
	color: black;
	text-transform: uppercase;
	font-size: 12px;
	width: 33.33%;
	float: left;
	position: relative;
        text-align: center;
}
#progressbar li:before {
	content: counter(step);
	counter-increment: step;
	width: 20px;
	line-height: 20px;
	display: block;
	font-size: 12px;
	color: white;
	background: black;
	border-radius: 3px;
	margin: 0 auto 5px auto;
}
/*progressbar connectors*/
#progressbar li:after {
	content: '';
	width: 100%;
	height: 2px;
	background: black;
	position: absolute;
	left: -50%;
	top: 9px;
	z-index: -1; /*put it behind the numbers*/
}
#progressbar li:first-child:after {
	/*connector not needed before the first step*/
	content: none; 
}
/*marking active/completed steps green*/
/*The number of the step and the connector before it = green*/
#progressbar li.active:before,  #progressbar li.active:after{
	background: #c11d29;
	color: white;
}
</style>
    
    
<script>
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(".next").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	next_fs = $(this).parent().next();
	
	//activate next step on progressbar using the index of next_fs
	$("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");
	
	//show the next fieldset
	next_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale current_fs down to 80%
			scale = 1 - (1 - now) * 0.2;
			//2. bring next_fs from the right(50%)
			left = (now * 50)+"%";
			//3. increase opacity of next_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'transform': 'scale('+scale+')'});
			next_fs.css({'left': left, 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});

$(".previous").click(function(){
	if(animating) return false;
	animating = true;
	
	current_fs = $(this).parent();
	previous_fs = $(this).parent().prev();
	
	//de-activate current step on progressbar
	$("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");
	
	//show the previous fieldset
	previous_fs.show(); 
	//hide the current fieldset with style
	current_fs.animate({opacity: 0}, {
		step: function(now, mx) {
			//as the opacity of current_fs reduces to 0 - stored in "now"
			//1. scale previous_fs from 80% to 100%
			scale = 0.8 + (1 - now) * 0.2;
			//2. take current_fs to the right(50%) - from 0%
			left = ((1-now) * 50)+"%";
			//3. increase opacity of previous_fs to 1 as it moves in
			opacity = 1 - now;
			current_fs.css({'left': left});
			previous_fs.css({'transform': 'scale('+scale+')', 'opacity': opacity});
		}, 
		duration: 800, 
		complete: function(){
			current_fs.hide();
			animating = false;
		}, 
		//this comes from the custom easing plugin
		easing: 'easeInOutBack'
	});
});
</script>
