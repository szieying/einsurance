<?php include('connect/session.db.php');?>
<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
          <li><a href="customerMain.php">Home</a></li>
        <li><a href="productCatalog.php">Insurance Plans</a></li>
        <li class="active"><a href="recommendationProcess.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<div id="r" class="container" style="margin-top:70px">
 <div>   
    <p><h2 class="text-center">PRODUCT RECOMMENDATION</h2></p><br>
 <div class="row">
    <?php include 'connect/productR.db.php' ?>
 </div></div>

</div><br>

 <?php echo "</form>" ?>
      
   
<?php include "templates/footer.php"; ?>
