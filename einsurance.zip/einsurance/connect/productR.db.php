<?php //include('session.db.php');
    include 'connection.php';
    $cType=$_SESSION['cType'];
    switch($cType){
        case 'low-end':
            $cScore=1;
            $cMaxScore=1.99;
            break;
        case 'middle-end':
            $cScore=2;
            $cMaxScore=2.99;
            break;
        case 'high-end':
            $cScore=3;
            $cMaxScore=3.99;
            break;
    }
    //echo $cType ."   ". $cScore;
    $appAge=$_SESSION['applicantAge'];
    $pType=$_SESSION['productType'];

    $sql = "SELECT * FROM product WHERE pScore>='$cScore' and pScore<='$cMaxScore' and pType='$pType' and pAgeRange_LLimit <= '$appAge' and pAgeRange_ULimit>='$appAge' limit 3";
    $result = $conn->query($sql);
    //if no result in database
    //Check whether the query was successful or not
    $count=1;
    if($result) {
      while(mysqli_num_rows($result) > 0 && $count>0 && $count<4) {
          echo "<form action='connect/2.db.php' method='post'>";
          $count++;
 	//Login Successful
	$product = mysqli_fetch_assoc($result);//fetch all the result inside the database
        
        switch($product['pCompany']){
            case 'Allianz':
            case 'Asia Pasifik':
            case 'AXA':
            case 'Great Eastern':
            case 'Prudential':
                $imgLink="http://localhost/eInsurance/img/company/".$product['pCompany'].".jpg";
                break;
            default:
                $imgLink="http://localhost/eInsurance/img/company/".$product['pCompany'].".png";
        }
        
        
        ?>

         

     
     <div class="col-sm-4" style="background-color:lavenderblush;"><!--p class="text-center" style="font-size: 18px;">Insurance Product</p--> <br> <div class="text-center">
  <div class="text-center">
      <img src=<?php echo $imgLink ?> class="img-responsive" style="width:100%;" alt="Image"><br>Product Company : <?php echo $product['pCompany'] ?><br>Product Name : <?php echo $product['pName'] ?><br>Product Coverage Lower Limit : <?php echo $product['pCoverage_LLimit'] ?><br>Product Coverage Upper Limit : <?php echo $product['pCoverage_ULimit'] ?>
             <br>Product Age Lower Limit : <?php echo $product['pAgeRange_LLimit'] ?><br>Product Age Upper Limit : <?php echo $product['pAgeRange_ULimit'] ?><br>Product Coverage Term : <?php echo $product['pCoverageTerm'] ?><br>
             Product Price : RM<?php echo $product['pPrice'] ?><br>
<br><br> <p>
    <!--td><input type='submit' name = 'Favourite' value='Favourite'></td> 
      <td><span class="glyphicon glyphicon-heart"></span> <input type='submit' name = 'Subscribe' value='Subscribe'></td>
      <input type="hidden" name="status" value=<//?php echo $product['pID']; ?>-->
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button>
  
  </p>
  </div>
         </div></div>
    <?php echo"</form>"; }
    
      } else {
    die("Query failed");
  }
  
  
  ?>
        
        
        