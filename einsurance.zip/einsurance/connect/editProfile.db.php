<?php
 
 if (isset($_POST['submitProfile'])){
      
    include 'connection.php';
    include 'session.db.php';
    
    $userID=$_SESSION['loginUser_ID'];
    $nickname=$_POST['Nickname'];
    $fName=$_POST['Fname'];
    $lName=$_POST['Lname'];
    $NRIC=$_POST['IC'];
    $gender=$_POST['Gender'];
    $dob=$_POST['DOB'];
    $phone=$_POST['Phone'];
    $address=$_POST['Address'];
    $salary=$_POST['Salary'];
    $career=$_POST['Career'];
    $employment=$_POST['EmploymentStatus'];
    $marital=$_POST['MaritalStatus'];
    $dependantsNum=$_POST['dependants'];
    $depCost=$_POST['DCost'];
    $mortgage=$_POST['Mortgage'];
    $livingCost=$_POST['LivingCost'];
    $sFrequency=$_POST['shopFrequency'];
    $sExpenses=$_POST['shopSpend'];
    
    $query = "INSERT INTO customer (cNRIC, cNickname, cFirstName, "
            . "cLastName, cGender, cDOB, cAddress, cPhoneNo, cMaritalStatus,"
            . "cCareer,employmentStatus,cSalary,numOfDependants,userID) "
            . "VALUES ('$NRIC', '$nickname', '$fName',"
            . "'$lName', '$gender', '$dob', '$address', '$phone', '$marital',"
            . "'$career', '$employment', '$salary', '$dependantsNum', '$userID' )";
    //$query = "INSERT INTO useraccount (userEmail, userPassword, userType) VALUES ('$email', '$password', 'C')";
    $result = $conn->query($query);
    
    $query1 = "INSERT INTO expenses (dependantsCost, mortgage, livingCost, "
            . "shoppingFrequency, shoppingRange, userID) "
            . "VALUES ('$depCost', '$mortgage', '$livingCost',"
            . "'$sFrequency', '$sExpenses', '$userID')";
    $result1 = $conn->query($query1);
    
    if($result && $result1){
        printAlert("Profile Inserted.");
    }else if (!$result && !$result1){
        printAlert("Failed to Insert Database");
    }
    else if(!$result){
        printAlert("Failed to Insert into Customer Database");
    }else if(!$result1){
        printAlert("Failed to Insert into Expenses Database");
    }
  }
  
  function printAlert($text){
        echo "<script language='javascript'>
                alert('$text');
                window.location.href = '../customerMain.php';
              </script>";
        die();
  }
?>