<?php
  
  if (isset($_POST['submitRegister'])){

    include 'connection.php';
    
    $email = $_POST['userEmail'];
    $password = $_POST['password'];
    $cpassword = $_POST['confirmPassword'];
    $sql = "SELECT userEmail FROM useraccount WHERE userEmail = '$email'";
    $result = $conn->query($sql);
    if(mysqli_num_rows($result) > 0)
    {
         printAlert("Email already exists! Please Log In.","1");
    }
    else{
          $query = "INSERT INTO useraccount (userEmail, userPassword, userType) VALUES ('$email', '$password', 'C')";
          $result1 = $conn->query($query);
          if($result1){
             session_start();
             $sql2 = "SELECT * FROM useraccount WHERE userEmail = '$email'";
             $result2 = $conn->query($sql2);
             //if no result in database
             //Check whether the query was successful or not
             if($result2) {
              if(mysqli_num_rows($result2) > 0) {
                    //Login Successful
                $login_user = mysqli_fetch_assoc($result2);//fetch all the result inside the database
        
                $_SESSION['loginUser_Email'] = $login_user['userEmail'];
                $_SESSION['loginUser_ID'] = $login_user['userID'];
                $_SESSION['loginUser_Type'] = $login_user['userType'];
                session_write_close();
                
                printAlert("User Created Successfully.","2");
              }
             }
          }
    }   
  }

  function printAlert($text, $case){
      switch ($case){
          case "1":
              echo "<script language='javascript'>
                        alert('$text');
                        window.location.href = '../index.php';
                    </script>";
                    die();
              break;
          case "2":
              echo "<script language='javascript'>
                        alert('$text');
                        window.location.href = '../editProfile.php';
                    </script>";
                    die();
              break;
      }
      
  }
?>