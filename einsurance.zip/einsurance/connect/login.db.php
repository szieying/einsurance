<?php
  session_start();

  if (isset($_POST['submitLogin'])){
      
    include_once 'connection.php';
    
    $userEmail =  $_POST['userEmail'];
    $password =  $_POST['password'];

    $sql = "SELECT * FROM useraccount WHERE userEmail = '$userEmail' and userPassword = '$password'";
    $result = $conn->query($sql);
    //if no result in database
    //Check whether the query was successful or not
    if($result) {
      if(mysqli_num_rows($result) > 0) {
 	//Login Successful
	$login_user = mysqli_fetch_assoc($result);//fetch all the result inside the database
        
  	$_SESSION['loginUser_Email'] = $login_user['userEmail'];
  	$_SESSION['loginUser_ID'] = $login_user['userID'];
  	$_SESSION['loginUser_Type'] = $login_user['userType'];
  	session_write_close();
  	if($_SESSION['loginUser_Type'] == 'A'){
            header("location: ../adminMain.php");
  	}
        else if($_SESSION['loginUser_Type'] == 'C'){
            header("location: ../customerMain.php");
        }
        exit();
      }
      else {
        //Login failed
        printAlert("Your username/password is incorrect.");
        session_write_close();
        exit();
      }
    }
  }
  else {
    die("Query failed");
  }

  function printAlert($text){
      echo "<script language='javascript'>
                  alert('$text');
                  window.location.href = '../index.php';
              </script>";
      die();
  }

?>