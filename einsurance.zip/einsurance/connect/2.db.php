<?php
 include 'connection.php';
 include 'session.db.php';
 
 $userID=$_SESSION['loginUser_ID'];
 
 if (isset($_POST['Delete'])){
     $listid = $_POST['list'];
     $pid = $_POST['p'];
     
     $select = "DELETE FROM fsproduct where pID='$pid' AND listID='$listid'";
     
     $query = mysqli_query($conn, $select) or die($select);
     
    // $result = mysqli_query($conn,$query);
     
     header ("Location: ../2.php");
 }
 else if (isset($_POST['Subscribe'])){
        
     
     $select9 = "SELECT * FROM list where userID='$userID' AND listType='S'";
     
     $query = mysqli_query($conn, $select9) or die(select9);
     if($query){
         if(mysqli_num_rows($query)>0){
             $subList = mysqli_fetch_assoc($query);
             
             $subListID = $subList['listID'];
     //$us = $_POST['user'];
     $li = $_POST['listtype'];
     $sub = $_POST['subStatus'];
     $listid = $_POST['list'];
     $pid = $_POST['p'];
     $datefs = $_POST['date'];
     //$dateS="2017-12-02";
 
    $select1="INSERT INTO fsproduct(pID, listID, dateFS, subscribeStatus)"
             . "VALUES ('$pid', '$subListID', '$datefs', 'P')";
 
    $select2 = "DELETE FROM fsproduct where pID='$pid' AND listID='$listid'";
            
 
     $query = mysqli_query($conn, $select1) or die($select1);
     $query = mysqli_query($conn, $select2) or die($select2);
 
     //$result = mysqli_query($conn,$query);   
 
     header ("Location: ../2.php");
 }

         }
    else{
        
     $select7="INSERT INTO list (listID, listType, userID) "
             . "VALUES ('17','S', '$userID')";
     
     $select8 = "SELECT * FROM list where userID='$userID' AND listType='S'";
     
     $query = mysqli_query($conn, $select8) or die(select8);
     
     
     if($query){
         if(mysqli_num_rows($query)>0){
             $subList = mysqli_fetch_assoc($query);
     
      $subListID = $subList['listID'];     
     
     
    $select3="INSERT INTO fsproduct(pID, listID, dateFS, subscribeStatus)"
             . "VALUES ('$pid', '$subListID', '$datefs', 'P')";
 
     $select4 = "DELETE FROM fsproduct where pID='$pid' AND listID='$listid'";
            
 
     $query = mysqli_query($conn, $select3) or die($select3);
     $query = mysqli_query($conn, $select4) or die($select4);
 
     //$result = mysqli_query($conn,$query);   
 
     header ("Location: ../2.php");
     }
                
                
    }
 }
 }  
?>

