<?php include('connection.php');
    session_start();
    
    $user_check=$_SESSION['loginUser_ID'];
    if($user_check == '1'){
        $login_session="admin";
    }
    else{
        $ses_sql = "SELECT cNickname FROM customer WHERE userID='$user_check' ";
        $result = $conn->query($ses_sql);
        if(mysqli_num_rows($result) > 0) {
            $row= mysqli_fetch_assoc($result);
            $login_session=", ".$row['cNickname'];
        }else{
            $login_session=" ";
        }
        if(!isset($_SESSION['loginUser_ID'])){
            header("location: ../index.php");
        }
    }
?>   