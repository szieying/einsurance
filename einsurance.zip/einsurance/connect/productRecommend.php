<?php
    include('session.db.php');
    
    if (isset($_POST['submitRecommend'])){
        $apAge=$_POST['age'];
        $productType=$_POST['pType'];
        $salary=$_POST['Salary'];
        $marital=$_POST['MaritalStatus'];
        $dependantsNum=$_POST['dependants'];
        $depCost=$_POST['DCost'];
        $mortgage=$_POST['Mortgage'];
        $livingCost=$_POST['LivingCost'];
        $sFrequency=$_POST['shopFrequency'];
        $sExpenses=$_POST['shopSpend'];
        $cAge=$_POST['CAge'];
        $userID=$_SESSION['loginUser_ID'];
        $_SESSION['productType']=$productType;
        $_SESSION['applicantAge']=$apAge;
        $_SESSION['salary']=$salary;
        $_SESSION['maritalStatus']=$marital;
        if($cAge < 20){
            $ageCategory=1;
        }else if($cAge < 30){
            $ageCategory=2;
        }else if($cAge < 40){
            $ageCategory=3;
        }else if($cAge < 50){
            $ageCategory=4;
        }else if($cAge >= 50){
            $ageCategory=5;
        }
        
        $_SESSION['ageCategory']=$ageCategory;
        
        switch($sExpenses){
            case '1': 
                $ssExp = 250;
                break;
            case '2': 
                $ssExp = 750;
                break;
            case '3': 
                $ssExp = 1250;
                break;
            case '4': 
                $ssExp = 1750;
                break;
            case '5': 
                $ssExp = 2500;
                break;
        }
        $tExpenses=$depCost+$mortgage+$livingCost+($sFrequency*$ssExp);
        
        if($tExpenses < 800){
            $exCategory=1;
        }else if($tExpenses < 1600){
            $exCategory=2;
        }else if($tExpenses < 2400){
            $exCategory=3;
        }else if($tExpenses < 3200){
            $exCategory=4;
        }else if($tExpenses >= 4000){
            $exCategory=5;
        }
        $_SESSION['eCategory']=$exCategory;
        header("location: ../treeAlgorithm.php");
    }
?>