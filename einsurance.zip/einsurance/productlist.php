 <?php include "connect/connection.php"; ?>
 <head>
	  <title>Product List</title>
	  <meta charset="utf-8">
	  <meta name="viewport" content="width=device-width, initial-scale=1">
	  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/headerstyle.css">
	  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
	  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	</head>

<body>
	<nav class="navbar navbar-default navbar-custom navbar-fixed-top">
	  <div class="container-fluid">
	    <div class="navbar-header">
	      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	        <span class="icon-bar"></span>
	      </button>
	      <a class="navbar-brand" href="http://localhost/eInsurance"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
	    </div>

    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li class="active"><a href="#">Home</a></li>
        <li><a href="#RecommendationProcess">What is Insurance?</a></li>
        <li><a href="#Services">Services Provided</a></li>
        <li><a href="#Partners">Our Partners</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right">
        <li class="dropdown">
          <a class="dropdown-toggle" href="#" data-toggle="dropdown"><span class="glyphicon glyphicon-user"></span>LOGIN</a>
          <div class="dropdown-menu" style="padding: 15px; padding-bottom: 10px;">
            <div class="login-box">
              <div class="login-box-body">
                      <p class="login-box-msg">eInsurance Members</p>
                    <form action="connect/login.php" method="post">
                      <div class="form-group has-feedback">
                        <input type="text" name="userEmail" placeholder="UserEmail" class="form-control" id="login" maxlength="80" size="30">
                        <span class="glyphicon glyphicon-user form-control-feedback"></span>
                        <span><font color="red"></font></span>
                      </div>

                      <div class="form-group has-feedback">
                        <input type="password" name="password" value="" placeholder="Password" class="form-control" id="password" size="30">
                        <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                        <span><font color="red"></font></span>
                      </div>

                      <div class="form-group">
                        <div class="row">
                            <div class="col-xs-7">
                                <a href="http://myadcubes.com/user/auth/forgot_password"><p><font color="GREEN">Forgot Password?</font></p></a>
                            </div>

                            <div class="col-xs-5 pull-right">
                                <input type="submit" name="submit" id="submit" tabindex="4" class="form-control btn btn-success" value="Log In">
                            </div>
                        </div>
                      </div>

                      <div class="form-group">
                        <div class="row">
                            <div class="col-sm-12">
                             <span>Not a member?</span><a href="register.php"><p><font color="GREEN">Sign up now</font></p></a>
                           </div>
                        </div>
                      </div>
                  </form>

                  </div>
                </div>
          </div>
      </ul>
    </div>
  </div>
</nav>

</body>

<body>

<style type="text/css">

.container {
overflow-y: auto;
height: 480px;
}
table {
border-spacing: 0;
width:400%;
}
</style>


   <style>
p.ex1 {
    margin-top: 3cm;
}
</style>
      
  <p class="ex1"><h2 class="text-center">Product List</h2></p><br>
  
  
  <div class="container">
  <table class="table table-bordered">
      <tr>
        <th class="text-center">Product Name</th>
        <th class="text-center" style="width:13%" >Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td></td>
        <td class="text-center"><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
      <tr>
        <td></td>
        <td class="text-center">  <button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
      <tr>
        <td></td>
        <td class="text-center"><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center"><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center"><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center"><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
	  <tr>
        <td></td>
        <td class="text-center" ><button type="button" class="btn btn-link ">Edit</button> <button type="button" class="btn btn-link">Delete</button></td>
      </tr>
    </tbody>
  </table>
   
</div>

</body><br><br><br>

<div class="form-actions">
            <div class="col-sm-offset-9 col-sm-80">
                    <button type="submit" class="submit btn btn-primary ">
                        ADD <i class="icon-angle-right"></i>
                    </button>
            
	</div>		
</div><br><br>


</html>
<?php include "templates/footer.php"; ?>
