<?php
$db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        
$select="INSERT INTO fsproduct (pID, listID, dateFS,subscribeStatus)
VALUES ('".$_GET['sub_id']."' ,'".$_GET['sub_id']."' ,'".$_GET['sub_id']."', 'P')";

$select = "SET FOREIGN_KEY_CHECKS=0";
$select1 = "UPDATE 'list'"
        . "SET 'listType' = 'S'" 
        . "WHERE list.listID='".$_GET['sub_id']."'"
        . "AND "
        ;

$select2 = "SET FOREIGN_KEY_CHECKS=1";

$query = mysqli_query($db, $select) or die($select);
$query = mysqli_query($db, $select1) or die($select1);
$query = mysqli_query($db, $select2) or die($select2);
echo "sadug";
$result = mysqli_query($db,$query);

header ("Location: 2.php");
?>