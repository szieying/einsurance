<?php include "templates/header.php"; ?>

<!-- TYPE CODE HERE (no need add doctype html and so on...directly add code!!)-->

<?php include "templates/footer.php"; ?>
