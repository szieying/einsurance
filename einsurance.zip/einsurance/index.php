<?php include "templates/header.php"; ?>
<a class="navbar-brand" href="index.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="">Home</a></li>
        
        <li><a href="#Services">How It Works?</a></li>
        <li><a href="#Partners">Our Partners</a></li>
      </ul>
      <ul class="nav navbar-nav navbar-right" style="padding-right:20px;">
        <li class="dropdown">
            <a data-toggle="modal" href="#loginModal"><span class="glyphicon glyphicon-user"></span><span style="color:#c11d29"> LOGIN</span></a>
      </ul>
    </div>
  </div>
</nav>

<div id="Services" class="container text-center" style="margin-top:70px">
  <?php include('serviceProvided.html'); ?>
    <hr>
</div>
<div id="Partners" class="container text-center">
   <?php include('partner.html'); ?> 
</div><br>


<?php include "templates/footer.php"; ?>

<div id="loginModal" class="modal fade" role="dialog">
    <div class="modal-dialog login-box">
	<div class="modal-content">
            <div class="modal-body">
		<ul class="nav nav-tabs">
                    <li class="active"><a href="#login" data-toggle="tab">Login</a></li>
                    <li><a href="#signup" data-toggle="tab">Sign Up</a></li>
		</ul>
                <div class="tab-content">
                    <div class="tab-pane fade active in" id="login">
                      <form action="connect/login.db.php" method="post">
                        <div class="form-group has-feedback" style="margin-top: 20px">
                            <label for="uname" class="control-label">Email Address</label>
                            <input type="email" name="userEmail" placeholder="Email" class="form-control" id="login" maxlength="30" size="30" required >
                            <span class="glyphicon glyphicon-user form-control-feedback"></span>
                            <span><font color="red"></font></span>
                        </div>

                        <div class="form-group has-feedback">
                            <label for="pass" class="control-label">Password</label>
                            <input type="password" name="password" value="" placeholder="Password" class="form-control" id="password" maxlength="15" size="30" required>
                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            <span><font color="red"></font></span>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-7">
                                    <a href="http://myadcubes.com/user/auth/forgot_password"><p><font color="#c11d29">Forgot Password?</font></p></a>
                                </div>

                                <div class="col-xs-5 pull-right">
                                    <input type="submit" name="submitLogin" id="submitLogin" tabindex="4" class="form-control btn" value="Log In">
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
                    <div class="tab-pane fade" id="signup">
                      <form id="signupform" name="registerForm" action="connect/register.db.php" method='post'>
			<div class="form-group has-feedback" style="margin-top: 20px">
                            <label for="uname" class="control-label">Email Address</label>
                            <input type="email" name="userEmail" placeholder="Email" class="form-control" id="login" maxlength="30" size="30" required>
                            <span class="glyphicon glyphicon-user form-control-feedback"></span>
                            <span><font color="red"></font></span>
                        </div>

                        <div class="form-group has-feedback">
                            <label for="pass" class="control-label">Password</label>
                            <input type="password" name="password" value="" placeholder="Password" class="form-control" id="regPassword" maxlength="15" size="30" required>
                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            <span><font color="red"></font></span>
                        </div>
                          
                        <div class="form-group has-feedback">
                            <label for="pass" class="control-label">Confirm Password</label>
                            <input type="password" name="confirmPassword" value="" placeholder="Confirm Password" class="form-control" id="confirmPassword" maxlength="15" size="30" required>
                            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                            <span><font color="red"></font></span>
                        </div>

                        <div class="form-group">
                            <div class="row">
                                <div class="col-xs-5 pull-right">
                                    <input type="submit" name="submitRegister" id="submitRegister" tabindex="4" class="form-control btn" value="Sign Up">
                                </div>
                            </div>
                        </div>
                      </form>
                    </div>
		</div>
            </div>
            <div class="modal-footer">
		<button class="btn btn-danger" data-dismiss="modal" type="button"> Close </button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.3/jquery.min.js"></script>
<script type="text/javascript">
    $(function () {
        $("#submitRegister").click(function () {
            var password = $("#regPassword").val();
            var confirmPassword = $("#confirmPassword").val();
            if (password != confirmPassword) {
                alert("Passwords do not match.");
                return false;
            }
            return true;
        });
    });
</script>