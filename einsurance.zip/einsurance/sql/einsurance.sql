-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 06, 2017 at 10:49 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 7.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `einsurance`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `cNRIC` varchar(15) COLLATE utf8_bin NOT NULL,
  `cNickname` varchar(30) COLLATE utf8_bin NOT NULL,
  `cFirstName` varchar(30) COLLATE utf8_bin NOT NULL,
  `cLastName` varchar(50) COLLATE utf8_bin NOT NULL,
  `cGender` char(1) COLLATE utf8_bin NOT NULL,
  `cDOB` date NOT NULL,
  `cAddress` varchar(150) COLLATE utf8_bin NOT NULL,
  `cPhoneNo` int(12) NOT NULL,
  `cMaritalStatus` char(1) COLLATE utf8_bin NOT NULL,
  `cCareer` varchar(30) COLLATE utf8_bin NOT NULL,
  `employmentStatus` int(1) NOT NULL COMMENT '1:No Job; 2:Employed; 3:Self-Employed; 4: Part-Time Worker; 5: Housewife',
  `cSalary` float NOT NULL,
  `numOfDependants` int(2) NOT NULL DEFAULT '0',
  `userID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cNRIC`, `cNickname`, `cFirstName`, `cLastName`, `cGender`, `cDOB`, `cAddress`, `cPhoneNo`, `cMaritalStatus`, `cCareer`, `employmentStatus`, `cSalary`, `numOfDependants`, `userID`) VALUES
('800630-10-5584', 'Aina', 'Aina', 'Mardiah', 'F', '1980-06-30', 'No. 10, Lorong Indah, Taman Indah, 43000 Kajang, Selangor.', 164449999, 'Y', 'Medical Assistant', 2, 2600, 3, 2),
('700909-01-5167', 'Thinish', 'Thinish', 'Kumar', 'M', '1970-09-09', '157, Jalan Senai Utama 1, Taman Senai Utama, 81400 Senai, Johor.', 175006478, 'Y', 'Teacher', 2, 2800, 1, 3),
('730101-02-5841', 'Lim', 'Lim', 'Kiwah', 'M', '1973-01-01', 'No. 17, Lorong Wawasan Jaya, Taman Wawasan, 34200 Parit Buntar, Perak.', 135561222, 'Y', 'Police Officer', 2, 3700, 1, 4),
('800108-11-5006', 'Suk', 'Suriah', 'Sukumar', 'F', '1980-08-01', 'Lot 1152, Kampung Gong Kiat, 20050 Kuala Terengganu, Terengganu.', 128744800, 'Y', 'Accountant', 3, 4100, 1, 5),
('890707-07-5243', 'Aingon', 'Khairul', 'Aimmar', 'M', '1989-07-07', 'No. 8, Lorong Kesumba 1, Taman Kesumba, 14200 Sungai Jawi, Pulau Pinang.', 174904901, 'Y', 'Nurse', 2, 2500, 1, 6),
('881205-13-5990', 'Mandy', 'Wong', 'Meichoo', 'F', '1988-05-12', 'No. 3, Taman Kopidims, 93250 Kuching, Sarawak.', 112348991, 'Y', 'Stewardess', 2, 3000, 1, 7),
('690301-10-5001', 'Teng Boo', 'Tan', 'Tengboo', 'M', '1969-01-03', 'No 13, Jalan Putra, Putra Heights, 47650 Subang Jaya, Selangor.', 167777123, 'Y', 'Engineer', 2, 6100, 1, 8),
('920505-07-5542', 'Nisa', 'Nur', 'Khairunnisa', 'F', '1992-05-05', '245, Kampung Baru, 11000 Bayan Lepas, Pulau Pinang,', 115577321, 'Y', 'Pharmacy Assistant', 2, 1797, 1, 9),
('651122-06-4994', 'Halimah', 'Nurul', 'Halimah', 'F', '1965-11-22', 'Lot 1709, Lorong Ilmu 9, Bandar Indera Mahkota, 25200 Kuantan, Pahang.', 128882221, 'Y', 'Lecturer', 2, 5501, 0, 10),
('911010-07-5501', 'Zul', 'Muhammad', 'Zulkhairi', 'M', '1991-10-10', '98, Kampung Jalan Tengah, 14000 Bukit Mertajam, Pulau Pinang.', 195555123, 'N', 'Production Operator', 2, 1990, 0, 11),
('850303-09-5111', 'Munish', 'Munishwaren', 'Maniam', 'M', '1985-03-03', '45, Jalan 1, Lorong Pekatra, Taman Pekatra Indah, 01000 Kangar, Perlis. ', 135677890, 'Y', 'Lawyer', 3, 4920.5, 1, 12),
('790506-05-5892', 'Cherry', 'Teoh', 'Chiakee', 'F', '1979-06-05', 'No 4, Lorong Suria 5, Taman Suria Indah, 70300 Seremban, Negeri Sembilan.', 129876543, 'Y', 'Doctor', 3, 6610, 2, 13),
('831111-12-5661', 'Muhammad', 'Muhammad', 'Zarif', 'M', '1983-11-11', '144, Jalan Tamparuli, Pekan Tamparuli, 99267 Tamparuli, Sabah.', 199876543, 'Y', 'Teacher', 2, 2200.5, 1, 14),
('930919-28-5888', 'Sangketa', 'Sangketa', 'Subramaniam', 'F', '1993-09-19', 'Lot 1234, Kampung Bahru, 15200 Kota Bharu, Kelantan.', 175555111, 'N', 'Clerk', 2, 1990, 0, 15),
('810831-02-5772', 'Siti', 'Siti', 'Zulaikha', 'F', '1981-08-31', 'No 16, Lorong Petani 6, Taman Baru Petani, 08000 Sungai Petani, Kedah.', 167890000, 'Y', 'Lab Assistant', 2, 2800, 1, 16),
('999999-10-9999', 'Jess', 'Lim', 'Yan', 'F', '1995-10-10', '44, Jalan Sungai Dua, 11700 Penang', 16, 'N', 'Student', 1, 0, 0, 17);

-- --------------------------------------------------------

--
-- Table structure for table `dependant`
--

CREATE TABLE `dependant` (
  `dFirstName` varchar(30) COLLATE utf8_bin NOT NULL,
  `dLastName` varchar(50) COLLATE utf8_bin NOT NULL,
  `dDOB` date NOT NULL,
  `dRelationship` int(1) NOT NULL COMMENT '1:spouse; 2:children; 3:parents; 4:siblings; 5:others',
  `userID` int(10) NOT NULL,
  `dID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `dependant`
--

INSERT INTO `dependant` (`dFirstName`, `dLastName`, `dDOB`, `dRelationship`, `userID`, `dID`) VALUES
('Nur', 'Aisyah', '2005-03-19', 2, 2, 1),
('Muhammad', 'Haikal', '2007-07-05', 2, 2, 2),
('Nur', 'Aqilah', '2009-02-22', 2, 2, 3),
('Suyanti', 'Previn', '1973-03-03', 1, 3, 4),
('Lim', 'Jiwen', '2000-11-11', 2, 4, 5),
('Sukumar', 'Vishnu', '1960-12-28', 3, 5, 6),
('Khairul', 'Fitri', '1994-08-22', 4, 6, 7),
('Adam', 'Harith', '2010-12-06', 2, 7, 8),
('Tan', 'Peiti', '1974-05-15', 1, 8, 9),
('Muhammad', 'Akmal', '1998-01-01', 4, 9, 10),
('Tivia', 'Arun', '1968-03-30', 3, 12, 11),
('Khor', 'Kiaweng', '1965-04-04', 3, 13, 12),
('Kim', 'Yinlin', '2002-02-22', 2, 13, 13),
('Nur', 'Zuriani', '1985-05-05', 1, 14, 14),
('Muhammad', 'Rizuan', '2008-07-11', 2, 16, 15);

-- --------------------------------------------------------

--
-- Table structure for table `expenses`
--

CREATE TABLE `expenses` (
  `dependantsCost` float NOT NULL,
  `mortgage` float NOT NULL,
  `livingCost` float NOT NULL,
  `shoppingFrequency` int(1) NOT NULL COMMENT '1:1/month; 2:2/month;3:3/month;4:1/week;5:2/week;6:>2/week',
  `shoppingRange` int(1) NOT NULL COMMENT '1:0-500; 2:501-1000; 3:1001-1500; 4:1501 -2000; 5:above2000',
  `userID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `expenses`
--

INSERT INTO `expenses` (`dependantsCost`, `mortgage`, `livingCost`, `shoppingFrequency`, `shoppingRange`, `userID`) VALUES
(225, 450, 800, 1, 1, 2),
(0, 300, 650, 2, 1, 3),
(200, 480, 760, 2, 1, 4),
(0, 500, 770, 3, 1, 5),
(0, 280, 580, 1, 1, 6),
(100, 410, 690, 2, 1, 7),
(0, 380, 990, 2, 2, 8),
(0, 290, 570, 1, 1, 9),
(0, 400, 890, 2, 2, 10),
(0, 250, 550, 1, 1, 11),
(0, 520, 930, 4, 1, 12),
(220, 550, 1100, 2, 2, 13),
(0, 300, 800, 1, 1, 14),
(0, 280, 620, 1, 1, 15),
(140, 400, 590, 1, 1, 16),
(0, 100, 500, 2, 1, 17);

-- --------------------------------------------------------

--
-- Table structure for table `fsproduct`
--

CREATE TABLE `fsproduct` (
  `pID` int(10) NOT NULL,
  `listID` int(10) NOT NULL,
  `dateFS` date NOT NULL,
  `subscribeStatus` char(1) COLLATE utf8_bin NOT NULL COMMENT 'A:Approved; R:Rejected; P:Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- --------------------------------------------------------

--
-- Table structure for table `list`
--

CREATE TABLE `list` (
  `listID` int(10) NOT NULL,
  `listType` char(1) COLLATE utf8_bin NOT NULL COMMENT 'F:Favourite;S:Subscribe',
  `userID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `list`
--

INSERT INTO `list` (`listID`, `listType`, `userID`) VALUES
(1, 'F', 2);

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `pID` int(10) NOT NULL,
  `pType` char(1) COLLATE utf8_bin NOT NULL COMMENT 'M:Medical; E:Education; S:Savings; L:Life',
  `pName` varchar(30) COLLATE utf8_bin NOT NULL,
  `pCoverage_LLimit` int(10) NOT NULL,
  `pCoverage_ULimit` int(10) NOT NULL,
  `pAgeRange_LLimit` int(3) NOT NULL,
  `pAgeRange_ULimit` int(3) NOT NULL,
  `pCoverageTerm` varchar(10) COLLATE utf8_bin NOT NULL,
  `pDescription` varchar(300) COLLATE utf8_bin NOT NULL,
  `pCompany` varchar(30) COLLATE utf8_bin NOT NULL,
  `pPrice` float NOT NULL,
  `pScore` float NOT NULL COMMENT 'Low:1.0-1.9; Med:2.0-2.9; High:3.0-3.9'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`pID`, `pType`, `pName`, `pCoverage_LLimit`, `pCoverage_ULimit`, `pAgeRange_LLimit`, `pAgeRange_ULimit`, `pCoverageTerm`, `pDescription`, `pCompany`, `pPrice`, `pScore`) VALUES
(1, 'M', 'ManuMedic-A', 100000, 1000000, 0, 70, 'A99', '', 'Manulife', 100, 1),
(2, 'M', 'Value Med-A', 150000, 1500000, 5, 70, 'A99', '', 'Prudential', 120, 1.1),
(3, 'M', 'Medisafe Infinite-A', 200000, 2000000, 10, 70, 'A99', '', 'Allianz', 140, 1.2),
(4, 'M', 'A-Life Med Regular-A', 250000, 2500000, 15, 70, 'A99', '', 'AIA', 160, 1.3),
(5, 'M', 'Value Med with MedSaver-A', 300000, 3000000, 20, 70, 'A99', '', 'Prudential', 180, 1.4),
(6, 'M', 'Omni Health-A', 100000, 2000000, 0, 70, 'A99', '', 'Zurich', 200, 1.5),
(7, 'M', 'Medic Partner-A', 150000, 3000000, 5, 70, 'A99', '', 'Tokyo Marine', 220, 1.6),
(8, 'M', 'A-Life Med Regular-i-A', 200000, 4000000, 10, 70, 'A99', '', 'AIA', 240, 1.7),
(9, 'M', 'Great Medicare-A', 250000, 5000000, 15, 70, 'A99', '', 'Great Eastern', 260, 1.8),
(10, 'M', 'Health Care Supreme-A', 300000, 6000000, 20, 70, 'A99', '', 'Tokyo Marine', 280, 1.9),
(11, 'M', 'ManuMedic-B', 100000, -1, 0, 70, 'A99', '', 'Manulife', 300, 2),
(12, 'M', 'Value Med-B', 150000, -1, 5, 70, 'A99', '', 'Prudential', 320, 2.1),
(13, 'M', 'Medisafe Infinite-B', 200000, -1, 10, 70, 'A99', '', 'Allianz', 340, 2.2),
(14, 'M', 'A-Life Med Regular-B', 250000, -1, 15, 70, 'A99', '', 'AIA', 360, 2.3),
(15, 'M', 'Value Med with MedSaver-B', 300000, -1, 20, 70, 'A99', '', 'Prudential', 380, 2.4),
(16, 'M', 'Omni Health-B', 350000, -1, 0, 70, 'A99', '', 'Zurich', 400, 2.5),
(17, 'M', 'Medic Partner-B', 400000, -1, 5, 70, 'A99', '', 'Tokyo Marine', 420, 2.6),
(18, 'M', 'A-Life Med Regular-i-B', 450000, -1, 10, 70, 'A99', '', 'AIA', 440, 2.7),
(19, 'M', 'Great Medicare-B', 500000, -1, 15, 70, 'A99', '', 'Great Eastern', 460, 2.8),
(20, 'M', 'Health Care Supreme-B', 550000, -1, 20, 70, 'A99', '', 'Tokyo Marine', 480, 2.9),
(21, 'M', 'ManuMedic-C', 600000, -1, 0, 70, 'A99', '', 'Manulife', 500, 3),
(22, 'M', 'Value Med-C', 650000, -1, 5, 70, 'A99', '', 'Prudential', 520, 3.1),
(23, 'M', 'Medisafe Infinite-C', 700000, -1, 10, 70, 'A99', '', 'Allianz', 540, 3.2),
(24, 'M', 'A-Life Med Regular-C', 750000, -1, 15, 70, 'A99', '', 'AIA', 560, 3.3),
(25, 'M', 'Value Med with MedSaver-C', 800000, -1, 20, 70, 'A99', '', 'Prudential', 580, 3.4),
(26, 'M', 'Omni Health-C', 850000, -1, 0, 70, 'A99', '', 'Zurich', 600, 3.5),
(27, 'M', 'Medic Partner-C', 900000, -1, 5, 70, 'A99', '', 'Tokyo Marine', 620, 3.6),
(28, 'M', 'A-Life Med Regular-i-C', 950000, -1, 10, 70, 'A99', '', 'AIA', 640, 3.7),
(29, 'M', 'Great Medicare-C', 1000000, -1, 15, 70, 'A99', '', 'Great Eastern', 660, 3.8),
(30, 'M', 'Health Care Supreme-C', 2000000, -1, 20, 70, 'A99', '', 'Tokyo Marine', 680, 3.9),
(31, 'L', 'TermLife-A', 100000, -1, 0, 70, 'A99', '', 'AIA', 100, 1),
(32, 'L', 'Life Cover-A', 150000, -1, 5, 70, 'A99', '', 'AIA', 120, 1.1),
(33, 'L', 'Ezy-Life Secure-A', 200000, -1, 10, 70, 'A99', '', 'Etiqa', 140, 1.2),
(34, 'L', 'i-EssentialCover-A', 250000, -1, 15, 70, 'A99', '', 'Allianz', 160, 1.3),
(35, 'L', 'i-DoubleSecure-A', 300000, -1, 20, 70, 'A99', '', 'Etiqa', 180, 1.4),
(36, 'L', 'SmartProtect Max-A', 350000, -1, 0, 70, 'A99', '', 'Great Eastern', 200, 1.5),
(37, 'L', 'A-Life ProtectTerm-A', 400000, -1, 5, 70, 'A99', '', 'AIA', 220, 1.6),
(38, 'L', 'PowerShield-A', 450000, -1, 10, 70, 'A99', '', 'Allianz', 240, 1.7),
(39, 'L', 'Pruterm-A', 500000, -1, 15, 70, 'A99', '', 'Prudential', 260, 1.8),
(40, 'L', 'Takaful Protect-A', 550000, -1, 20, 70, 'A99', '', 'Prudential', 280, 1.9),
(41, 'L', 'TermLife-B', 600000, -1, 0, 70, 'A99', '', 'AIA', 300, 2),
(42, 'L', 'Life Cover-B', 650000, -1, 5, 70, 'A99', '', 'AIA', 320, 2.1),
(43, 'L', 'Ezy-Life Secure-B', 700000, -1, 10, 70, 'A99', '', 'Etiqa', 340, 2.2),
(44, 'L', 'i-EssentialCover-B', 750000, -1, 15, 70, 'A99', '', 'Allianz', 360, 2.3),
(45, 'L', 'i-DoubleSecure-B', 800000, -1, 20, 70, 'A99', '', 'Etiqa', 380, 2.4),
(46, 'L', 'SmartProtect Max-B', 900000, -1, 0, 70, 'A99', '', 'Great Eastern', 400, 2.5),
(47, 'L', 'A-Life ProtectTerm-B', 1000000, -1, 5, 70, 'A99', '', 'AIA', 420, 2.6),
(48, 'L', 'PowerShield-B', 1100000, -1, 10, 70, 'A99', '', 'Allianz', 440, 2.7),
(49, 'L', 'Pruterm-B', 1200000, -1, 15, 70, 'A99', '', 'Prudential', 460, 2.8),
(50, 'L', 'Takaful Protect-B', 1300000, -1, 20, 70, 'A99', '', 'Prudential', 480, 2.9),
(51, 'L', 'TermLife-C', 1400000, -1, 0, 70, 'A99', '', 'AIA', 500, 3),
(52, 'L', 'Life Cover-C', 1500000, -1, 5, 70, 'A99', '', 'AIA', 520, 3.1),
(53, 'L', 'Ezy-Life Secure-C', 2000000, -1, 10, 70, 'A99', '', 'Etiqa', 540, 3.2),
(54, 'L', 'i-EssentialCover-C', 2500000, -1, 15, 70, 'A99', '', 'Allianz', 560, 3.3),
(55, 'L', 'i-DoubleSecure-C', 3000000, -1, 20, 70, 'A99', '', 'Etiqa', 580, 3.4),
(56, 'L', 'SmartProtect Max-C', 3500000, -1, 0, 70, 'A99', '', 'Great Eastern', 600, 3.5),
(57, 'L', 'A-Life ProtectTerm-C', 4000000, -1, 5, 70, 'A99', '', 'AIA', 620, 3.6),
(58, 'L', 'PowerShield-C', 4500000, -1, 10, 70, 'A99', '', 'Allianz', 640, 3.7),
(59, 'L', 'Pruterm-C', 5000000, -1, 15, 70, 'A99', '', 'Prudential', 660, 3.8),
(60, 'L', 'Takaful Protect-C', 6000000, -1, 20, 70, 'A99', '', 'Prudential', 680, 3.9),
(61, 'S', 'PrimeSaver-A', 100, -1, 0, 70, 'Y20', '', 'Allianz', 100, 1),
(62, 'S', 'MillionA Plan-A', 150, -1, 5, 70, 'Y20', '', 'AXA', 150, 1.1),
(63, 'S', 'MillionA+-A', 200, -1, 10, 70, 'Y20', '', 'AXA', 200, 1.2),
(64, 'S', 'A-Plus Enrich20-A', 250, -1, 15, 70, 'Y20', '', 'AIA', 250, 1.3),
(65, 'S', 'A‑Enrich​Gold‑i-A', 300, -1, 20, 70, 'Y20', '', 'AIA', 300, 1.4),
(66, 'S', 'TokyoMarine-More-A', 400, -1, 0, 70, 'Y20', '', 'Tokyo Marine', 400, 1.5),
(67, 'S', 'FlexiSaver-A', 500, -1, 5, 70, 'Y20', '', 'Allianz', 500, 1.6),
(68, 'S', 'PRUcash-A', 600, -1, 10, 70, 'Y20', '', 'Prudential', 600, 1.7),
(69, 'S', 'PRUcash premier-A', 700, -1, 15, 70, 'Y20', '', 'Prudential', 700, 1.8),
(70, 'S', 'A-EnrichGold-A', 800, -1, 20, 70, 'Y20', '', 'AIA', 800, 1.9),
(71, 'S', 'PrimeSaver-B', 900, -1, 0, 70, 'Y20', '', 'Allianz', 900, 2),
(72, 'S', 'MillionA Plan-B', 1000, -1, 5, 70, 'Y20', '', 'AXA', 1, 2.1),
(73, 'S', 'MillionA+-B', 1500, -1, 10, 70, 'Y20', '', 'AXA', 1, 2.2),
(74, 'S', 'A-Plus Enrich20-B', 2000, -1, 15, 70, 'Y20', '', 'AIA', 2, 2.3),
(75, 'S', 'A‑Enrich​Gold‑i-B', 2500, -1, 20, 70, 'Y20', '', 'AIA', 2, 2.4),
(76, 'S', 'TokyoMarine-More-B', 3000, -1, 0, 70, 'Y20', '', 'Tokyo Marine', 3, 2.5),
(77, 'S', 'FlexiSaver-B', 3500, -1, 5, 70, 'Y20', '', 'Allianz', 3, 2.6),
(78, 'S', 'PRUcash-B', 4000, -1, 10, 70, 'Y20', '', 'Prudential', 4, 2.7),
(79, 'S', 'PRUcash premier-B', 4500, -1, 15, 70, 'Y20', '', 'Prudential', 4, 2.8),
(80, 'S', 'A-EnrichGold-B', 5000, -1, 20, 70, 'Y20', '', 'AIA', 5, 2.9),
(81, 'S', 'PrimeSaver-C', 5500, -1, 0, 70, 'Y20', '', 'Allianz', 5, 3),
(82, 'S', 'MillionA Plan-C', 6000, -1, 5, 70, 'Y20', '', 'AXA', 6, 3.1),
(83, 'S', 'MillionA+-C', 6500, -1, 10, 70, 'Y20', '', 'AXA', 6, 3.2),
(84, 'S', 'A-Plus Enrich20-C', 7000, -1, 15, 70, 'Y20', '', 'AIA', 7, 3.3),
(85, 'S', 'A‑Enrich​Gold‑i-C', 7500, -1, 20, 70, 'Y20', '', 'AIA', 7, 3.4),
(86, 'S', 'TokyoMarine-More-C', 8000, -1, 0, 70, 'Y20', '', 'Tokyo Marine', 8, 3.5),
(87, 'S', 'FlexiSaver-C', 8500, -1, 5, 70, 'Y20', '', 'Allianz', 8, 3.6),
(88, 'S', 'PRUcash-C', 9000, -1, 10, 70, 'Y20', '', 'Prudential', 9, 3.7),
(89, 'S', 'PRUcash premier-C', 9500, -1, 15, 70, 'Y20', '', 'Prudential', 9, 3.8),
(90, 'S', 'A-EnrichGold-C', 10000, -1, 20, 70, 'Y20', '', 'AIA', 10, 3.9),
(91, 'E', 'A-EduAchieve-A', 100, -1, 0, 70, 'Y20', '', 'AIA', 100, 1),
(92, 'E', 'PRUlink-A', 150, -1, 5, 70, 'Y20', '', 'Prudential', 150, 1.1),
(93, 'E', 'SmartEucate Saver-A', 200, -1, 10, 70, 'Y20', '', 'Great Eastern', 200, 1.2),
(94, 'E', 'EduSaving-A', 250, -1, 15, 70, 'Y20', '', 'Allianz', 250, 1.3),
(95, 'E', 'Wealth Edu-A', 300, -1, 20, 70, 'Y20', '', 'AXA', 300, 1.4),
(96, 'E', 'TakafulEdu-A', 400, -1, 0, 70, 'Y20', '', 'Etiqa', 400, 1.5),
(97, 'E', 'Education Savings Plan-A', 500, -1, 5, 70, 'Y20', '', 'Tokyo Marine', 500, 1.6),
(98, 'E', 'Education Insurance-A', 600, -1, 10, 70, 'Y20', '', 'Maybank', 600, 1.7),
(99, 'E', 'Asia FlexEd Plus-A', 700, -1, 15, 70, 'Y20', '', 'Asia Pasifik', 700, 1.8),
(100, 'E', 'Asia Predict Child-A', 800, -1, 20, 70, 'Y20', '', 'Asia Pasifik', 800, 1.9),
(101, 'E', 'A-EduAchieve-B', 900, -1, 0, 70, 'Y20', '', 'AIA', 900, 2),
(102, 'E', 'PRUlink-B', 1000, -1, 5, 70, 'Y20', '', 'Prudential', 1, 2.1),
(103, 'E', 'SmartEucate Saver-B', 1500, -1, 10, 70, 'Y20', '', 'Great Eastern', 1, 2.2),
(104, 'E', 'EduSaving-B', 2000, -1, 15, 70, 'Y20', '', 'Allianz', 2, 2.3),
(105, 'E', 'Wealth Edu-B', 2500, -1, 20, 70, 'Y20', '', 'AXA', 2, 2.4),
(106, 'E', 'TakafulEdu-B', 3000, -1, 0, 70, 'Y20', '', 'Etiqa', 3, 2.5),
(107, 'E', 'Education Savings Plan-B', 3500, -1, 5, 70, 'Y20', '', 'Tokyo Marine', 3, 2.6),
(108, 'E', 'Education Insurance-B', 4000, -1, 10, 70, 'Y20', '', 'Maybank', 4, 2.7),
(109, 'E', 'Asia FlexEd Plus-B', 4500, -1, 15, 70, 'Y20', '', 'Asia Pasifik', 4, 2.8),
(110, 'E', 'Asia Predict Child-B', 5000, -1, 20, 70, 'Y20', '', 'Asia Pasifik', 5, 2.9),
(111, 'E', 'A-EduAchieve-C', 5500, -1, 0, 70, 'Y20', '', 'AIA', 5, 3),
(112, 'E', 'PRUlink-C', 6000, -1, 5, 70, 'Y20', '', 'Prudential', 6, 3.1),
(113, 'E', 'SmartEucate Saver-C', 6500, -1, 10, 70, 'Y20', '', 'Great Eastern', 6, 3.2),
(114, 'E', 'EduSaving-C', 7000, -1, 15, 70, 'Y20', '', 'Allianz', 7, 3.3),
(115, 'E', 'Wealth Edu-C', 7500, -1, 20, 70, 'Y20', '', 'AXA', 7, 3.4),
(116, 'E', 'TakafulEdu-C', 8000, -1, 0, 70, 'Y20', '', 'Etiqa', 8, 3.5),
(117, 'E', 'Education Savings Plan-C', 8500, -1, 5, 70, 'Y20', '', 'Tokyo Marine', 8, 3.6),
(118, 'E', 'Education Insurance-C', 9000, -1, 10, 70, 'Y20', '', 'Maybank', 9, 3.7),
(119, 'E', 'Asia FlexEd Plus-C', 9500, -1, 15, 70, 'Y20', '', 'Asia Pasifik', 9, 3.8),
(120, 'E', 'Asia Predict Child-C', 10000, -1, 20, 70, 'Y20', '', 'Asia Pasifik', 10, 3.9);

-- --------------------------------------------------------

--
-- Table structure for table `useraccount`
--

CREATE TABLE `useraccount` (
  `userEmail` varchar(30) COLLATE utf8_bin NOT NULL,
  `userPassword` varchar(15) COLLATE utf8_bin NOT NULL,
  `userID` int(10) NOT NULL,
  `userType` char(1) COLLATE utf8_bin NOT NULL DEFAULT 'C' COMMENT 'Admin; C:Customer'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `useraccount`
--

INSERT INTO `useraccount` (`userEmail`, `userPassword`, `userID`, `userType`) VALUES
('admin@einsurance', 'admin', 1, 'A'),
('ainamardiah@yahoo.com', 'ain246801', 2, 'C'),
('thinishk@gmail.com', '70tkumar11', 3, 'C'),
('lkw@gmail.com', '9871230', 4, 'C'),
('suria@hotmail.com', 'sskumar80', 5, 'C'),
('aimmar@gmail.com', 'khaimm44123', 6, 'C'),
('wmchoo88@gmail.com', 'xandra88', 7, 'C'),
('tan69@yahoo.com', 'ttbeng69', 8, 'C'),
('nurnisa@gmail.com', '7n7n77777', 9, 'C'),
('halimah65@outlook.com', 'nhabcdef881', 10, 'C'),
('mzulkhairi@aol.com', 'aaaazyxw', 11, 'C'),
('munishmaniam@gmail.com', 'qwertasdfgzxc', 12, 'C'),
('teohck@yahoo.com', 'teoh123456789', 13, 'C'),
('zarifm83@hotmail.com', 'm9876543210', 14, 'C'),
('ssangketa@gmail.com', 'mnbvcxzlkjhg99', 15, 'C'),
('sitizulaikha@gmail.com', '1234567890aab', 16, 'C'),
('yan@mail.com', '123456', 17, 'C');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `dependant`
--
ALTER TABLE `dependant`
  ADD PRIMARY KEY (`dID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `expenses`
--
ALTER TABLE `expenses`
  ADD PRIMARY KEY (`userID`);

--
-- Indexes for table `fsproduct`
--
ALTER TABLE `fsproduct`
  ADD PRIMARY KEY (`pID`,`listID`),
  ADD KEY `listID` (`listID`);

--
-- Indexes for table `list`
--
ALTER TABLE `list`
  ADD PRIMARY KEY (`listID`),
  ADD KEY `userID` (`userID`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`pID`);

--
-- Indexes for table `useraccount`
--
ALTER TABLE `useraccount`
  ADD PRIMARY KEY (`userID`),
  ADD UNIQUE KEY `userEmail` (`userEmail`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dependant`
--
ALTER TABLE `dependant`
  MODIFY `dID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `pID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=121;

--
-- AUTO_INCREMENT for table `useraccount`
--
ALTER TABLE `useraccount`
  MODIFY `userID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customer`
--
ALTER TABLE `customer`
  ADD CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `useraccount` (`userID`);

--
-- Constraints for table `dependant`
--
ALTER TABLE `dependant`
  ADD CONSTRAINT `dependant_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `customer` (`userID`);

--
-- Constraints for table `expenses`
--
ALTER TABLE `expenses`
  ADD CONSTRAINT `expenses_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `customer` (`userID`);

--
-- Constraints for table `fsproduct`
--
ALTER TABLE `fsproduct`
  ADD CONSTRAINT `fsproduct_ibfk_2` FOREIGN KEY (`listID`) REFERENCES `list` (`listID`),
  ADD CONSTRAINT `fsproduct_ibfk_3` FOREIGN KEY (`pID`) REFERENCES `product` (`pID`);

--
-- Constraints for table `list`
--
ALTER TABLE `list`
  ADD CONSTRAINT `list_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `useraccount` (`userID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
