<?php
$db = mysqli_connect('localhost','root','','einsurance')
        or die('Error connecting to MySQL server.');
        
        
$select = "DELETE FROM fsproduct where pID='".$_GET['p_ID']."' AND listID='".$_GET['list_ID']."'";

$query = mysqli_query($db, $select) or die($select);

$result = mysqli_query($db,$query);

echo $_GET['list_ID']
?>