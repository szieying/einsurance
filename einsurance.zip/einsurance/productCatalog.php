<?php include('connect/session.db.php');?>
<?php include ('templates/header.php'); ?>
<a class="navbar-brand" href="customerMain.php"><img src="http://localhost/eInsurance/img/logo.png" alt="eInsurance"></a>
</div>
<div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="customerMain.php">Home</a></li>
        <li class="active"><a href="productCatalog.php">Insurance Plans</a></li>
        <li><a href="recommendationProcess.php">Recommendation</a></li>
      </ul>
      <?php include ('templates/navBarRight.html'); ?> 
    </div>
  </div>
</nav>

<style>
p.ex1 {
    margin-top: 3cm;
}
</style>
<body>

<style type="text/css">

.container {
overflow-y: auto;
height: 480px;
}
table {
border-spacing: 0;
width:400%;
}
</style>


   
      
  <p class="ex1"><h2 class="text-center" >PRODUCT CATALOG</h2></p><br>
  
  
  <div class="container">
  <table class="table table-bordered">
      <tr>
        <th class="text-center">Insurance Product</th>
        <th class="text-center" style="width:30%" >Action</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"> <br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
      <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"> <br><br><br><br> <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
      <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center"><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td></td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  <tr>
        <td><br>Product Name : <br>Product Coverage Lower Limit : <br>Product Coverage Upper Limit :
             <br>Product Age Lower Limit : <br>Product Age Upper Limit : <br>Product Coverage Term : <br>Product Description : <br>Product Price : RM<br>Product Score :</td>
        <td class="text-center" ><br><br><br><br><button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-star"></span> Favourite
    </button>  
    <button type="button" class="btn btn-default">
      <span class="glyphicon glyphicon-heart"></span> Subscribe
    </button></td>
      </tr>
	  
    </tbody>
  </table>
   
</div>

</body><br><br><br>






<?php include "templates/footer.php"; ?>
